#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec 29 10:03:18 2021

Fashion Finder

Bloques:
1. Segmentación objeto - fondo
2. Red neuronal
3. Scrapy (llamada a arañas)
4. GUI

@authors: Emilia Pérez, Pablo Montes
"""
import cv2 as cv
from picamera.array import PiRGBArray
from picamera import PiCamera
import time
import numpy as np
import subprocess
import os
import PySimpleGUI as sg 
import urllib.request 
import json
import base64
from PIL import Image
import io
# importamos el modulo de GPIO
import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BOARD) # definimos la numeracion 
GPIO.setup(7, GPIO.OUT) # definimos el pin como salida
GPIO.output(7, GPIO.LOW) # Inicializamos a 0 el pin  


#%%
"""
1. Segmentación objeto fondo
"""

def procesar_imagen(img):
    #Primer paso: Cortar
    arrays = np.nonzero(img)

    imin = np.min(arrays[0][:])
    imax = np.max(arrays[0][:])
    jmin = np.min(arrays[1][:])
    jmax = np.max(arrays[1][:])
    
    cropped = img[imin:imax, jmin:jmax]
    #cv.imshow("Hola",cropped)
    #key = cv.waitKey(0)

    #Segundo paso: Pasar el borde largo a 28 pix
    alto = imax-imin
    ancho = jmax-jmin
    max_dim = max(alto,ancho)
    scale_percent=int((100*28)/max_dim)
    if max_dim == alto:
        width = int(cropped.shape[1] * scale_percent / 100)
        dim = (28, width)
    else:
        height = int(cropped.shape[0] * scale_percent / 100)
        dim = (height, 28)
    
    # resize image
    img_28 = cv.resize(cropped, dim, interpolation = cv.INTER_AREA)
    #cv.imshow("Hola",img_28)
    #key = cv.waitKey(0)
    
    #Tercer paso: Afilar bordes
    #sharpen = np.array([[0, -1, 0],[-1, 5, -1],[0, -1, 0]])
    
    #img_sharp = cv.filter2D(img_28, -1, sharpen) 
    #cv.imshow("Sharpenned",img_sharp)
    #key = cv.waitKey(0)
    
    #Cuarto paso: Pasar borde corto a 28 pix
    if img_28.shape[1] == 28:
        height_diff = 28 - img_28.shape[0]
        img_final = np.append(np.zeros([int(height_diff/2),28]).astype('uint8'), img_28, axis=0)
        img_final = np.append(img_final, np.zeros([height_diff - int(height_diff/2),28]).astype('unit8'),axis=0)
    else:
        width_diff = 28 - img_28.shape[1]
        img_final = np.append(np.zeros([28,int(width_diff/2)]).astype('uint8'), img_28, axis=1) 
        img_final = np.append(img_final, np.zeros([28, width_diff - int(width_diff/2)]).astype('uint8'),axis=1)
         
    #cv.imshow("Final",img_final)
    #key = cv.waitKey(0)
    
    #Quinto paso: Fondo negro (ya lo tenemos)
    #Sexto paso: Pasar a niveles de gris de 8 bits
    
    #Septimo paso: guardar la imagen
    cv.imwrite('img_def.png', img_final)
    return img_final
    
    
#%%----------------------------------------------------
"""
2. Red Neuronal (previamente entrenada)
"""

def red_neuronal(img):
    # Clasificador para Rpi basado en CNN
    
    from tensorflow.keras.models import Sequential
    from tensorflow.keras.layers import Dense, Conv2D, MaxPooling2D, Flatten, Dropout
    import numpy as np
    from PIL import Image
    
    # CNN para MNIST Digit
    nombre = "CNN_Default"
    model = Sequential()
    model.add(Conv2D(32, (5, 5), activation='relu', input_shape=(28, 28, 1)))
    model.add(MaxPooling2D((2, 2)))
    # Olvidamos temporalmente 18% de las neuronas
    model.add(Dropout(0.25))
    model.add(Conv2D(64, (5, 5), activation='relu'))
    model.add(MaxPooling2D((2, 2)))
    model.add(Flatten())
    model.add(Dense(10, activation='softmax'))
    model.summary()
    
    
    nombre = nombre + "_b32_e10_"
    
    nombre = nombre + "_Adam_"
    model.load_weights(nombre + '.h5')
    
    #Predecimos una imagen
    #img = Image.open('img_def.png').convert('L')
    #img_array = np.array(img)
    #img_array = 255-img_array
    img_array = img[np.newaxis, :,:, np.newaxis]
    
    prediccion=np.argmax(model.predict(img_array));
    
    return prediccion
    #print("PREDICCIÓN:", np.argmax(model.predict(img_array)))
    
#----------------------------------------------------  
def base64encoder():
    OUTPUT_FILENAME = 'output.txt'
    """
    #Importante: cambiar este directorio cuando sea necesario.
     Ejemplo:
     folder="/home/pi/a_proyecto_emi_pablo2021/Asos-Basic-master/asos_crawler/spiders/imagenes"
    """
    folder="/home/pi/a_proyecto_emi_pablo2021/Asos-Basic-master/asos_crawler/spiders/imagenes"
    
    if not folder:
        sg.popup_cancel('Cancelled - No valid folder entered. Please look at line 146, base64encoder() in Fashion_Finder.py')
        return
    try:
        namesonly = [f for f in os.listdir(folder) if f.endswith('.png') or f.endswith('.ico') or f.endswith('.gif')]
    except:
        sg.popup_cancel('Cancelled - No valid folder entered')
        return

    outfile = open(os.path.join(folder, OUTPUT_FILENAME), 'w')

    for i, file in enumerate(namesonly):
        contents = open(os.path.join(folder, file), 'rb').read()
        encoded = base64.b64encode(contents)
        outfile.write('\n{} = {}'.format(file[:file.index(".")], encoded))
        sg.OneLineProgressMeter('Base64 Encoding', i+1, len(namesonly), key='-METER-')

    outfile.close()
    sg.popup('Completed!', 'Encoded %s files'%(i+1))
    
#----------------------------------------------------    
#%%
"""
Fotografía continua (main, estrictamente).
Debe comentarse si se pretende utilizar con imagen de archivo previamente procesada
"""


camera = PiCamera()
camera.resolution = (320, 240)
camera.framerate = 30
camera.rotation = 0
rawCapture = PiRGBArray(camera, size=(320, 240))

## Ofrece un tiempo a la cámara para arrancar
time.sleep(1)

camera.capture(rawCapture, format="bgr", use_video_port=True)
first = rawCapture.array
#cv.imshow("First", first)
#Acaba con imagen raw
rawCapture.truncate(0)


plantilla = cv.getStructuringElement(cv.MORPH_ELLIPSE,(7,9))

gray1 = cv.cvtColor(first, cv.COLOR_BGR2GRAY)


for frame in camera.capture_continuous(rawCapture, format="bgr", use_video_port=True):

    image = frame.array
    cv.imshow("Continuo", image)
    

    gray2 = cv.cvtColor(image, cv.COLOR_BGR2GRAY)

    mask = cv.absdiff(gray1, gray2)  
    #cv.imshow("Difference", mask)

    _, mask0 = cv.threshold(mask, 50, 255, cv.THRESH_BINARY)
    #cv.imshow("Mask", mask0)

    mask1 = cv.morphologyEx(mask0, cv.MORPH_CLOSE, plantilla)

    #cv.imshow("Huecos", mask1)

    res1=np.array(mask0 & gray2)
    res2 = res1 * 255. / np.max(np.max(res1))
    res3 = np.array(res2).astype('uint8')    
    
    cv.imshow("Final", res3) 

    key = cv.waitKey(1) & 0xFF

    rawCapture.truncate(0)

    if key == ord("q"):
        cv.imwrite('resultado_filtrado.png', res3)
        break

camera.close()
cv.destroyAllWindows()

img = cv.imread('resultado_filtrado.png', cv.IMREAD_GRAYSCALE)

img_procesada=procesar_imagen(img)

#-------------------------------------------------------------------------------
"""
 Preparación GUI
"""
layout =  [[sg.Button('Hombre'), sg.Button('Mujer')]]
window = sg.Window('Choose your gender', layout)
event, values = window.read()
window.close()
print(event)
if(event=='Hombre'):
    gender=1
    sg.theme('LightTeal')
else:
    gender=0
    sg.theme('Dark Teal 5')
print(gender)

"""
Descomente estas líneas para introducir imágenes previamente procesadas
#img_procesada = cv.imread('pullover.png', cv.IMREAD_GRAYSCALE)
#img_procesada = cv.imread('pantalon.png', cv.IMREAD_GRAYSCALE)
#img_procesada = cv.imread('top.png', cv.IMREAD_GRAYSCALE)
#img_procesada = cv.imread('ankleboots.png', cv.IMREAD_GRAYSCALE)

#-------------------------------------------------------------------------------
"""

"""
Llamada a red neuronal (2)
"""
clasificacion=red_neuronal(img_procesada)
print (clasificacion)

# 0: camiseta o top
# 1: pantalon
# 2: pullover
# 3: vestido
# 4: abrigo
# 5: sandalia
# 6: camisa
# 7: sneaker
# 8: bolso
# 9: ankle boots

# Englobando resultados
# CLASE 1: 1
# CLASE 2: 2, 4, 6
# CLASE 3: 5, 7, 9
# CLASE 4: 3
# CLASE 5: 0

"""
3. Llamada a arañas
"""
if clasificacion==1:
    if gender==1:
        spider = "asos_pantalones"
    else:
        spider = "asos_pantalones_mujer"
elif clasificacion==3:
    spider = "asos_vestido"
elif (clasificacion==5 or clasificacion==7 or clasificacion==9):
    if gender==1:
        spider = "asos_zapatos"
    else:
        spider = "asos_zapatos_mujer"
elif clasificacion==0:
    if gender==1:
        spider = "asos_top"
    else:
        spider = "asos_top_mujer"
else:
    if gender==1:
        spider = "asos_chaquetas"
    else:
        spider = "asos_chaquetas_mujer"

command_return=subprocess.call(["scrapy","crawl",spider,"-o", "resultados.json"])

file = open('resultados.json')
#print(file)
datos = json.load(file)
#print (datos)

objetos = []
for i in range(len(datos)):
    img_objeto = datos[i]['imagen']
    objetos_dict = dict()
    objetos_dict['idx'] = i
    objetos_dict['nombre'] = "imagenes/imagen"+str(i)+".png"
    objetos_dict['precio'] = datos[i]['price']
    objetos_dict['descripcion'] = datos[i]['product_name']
    objetos.append(objetos_dict)
    urllib.request.urlretrieve(img_objeto,"imagenes/imagen"+str(i)+".png")

json_dict = json.dumps(objetos)
json_file = open("imagenes/output_dict.json", "w")
json_file.write(json_dict)
json_file.close()

#sg.theme('LightTeal')

file = open('imagenes/output_dict.json')
datos = json.load(file)

"""
4. GUI
"""

image_viewer_column = [
                        [sg.Image(key="image")]
                      ]

text_column = [
                [sg.Text("                               Detalles:             ",size=(40, 1), key="imagetext1")],
                [sg.Text("------------------------------------------------------------------------------",size=(40, 1), key="imagetext0")],
                [sg.Text("Nombre:",size=(40, 1), key="imagetext2")],
                [sg.Text("Precio:",size=(40, 1), key="imagetext3")],
                      ]

but_col=[
            [sg.Button("Next")],
            [sg.Button("Previous")],
            [sg.Button("I want it!")]
        ]

layout = [
        [sg.Column(but_col),
        sg.VSeperator(),
        sg.Column(image_viewer_column),
         sg.VSeperator(),
         sg.Column(text_column)
        ],
    
]


"""
Incluye activación de pines
"""

window = sg.Window('Image Editor', layout)

idx = -1
while True:
    event, values = window.read()
    if event in (sg.WIN_CLOSED, 'Exit'):
        break
    if event == sg.WIN_CLOSED or event == 'Exit':
        break
    else:
        if event:
            if event=="Next":
                idx = idx + 1 if idx < 15 else 15
                filename = datos[idx]['nombre']
                img = Image.open(filename)
                bio = io.BytesIO()
                img.save(bio, format="PNG")
                window['image'].update(data=bio.getvalue())
                
                text = 'Nombre: ' + datos[idx]['descripcion'][:30] + '...'
                window['imagetext2'].update(value=text)
                
                text = 'Precio: ' + datos[idx]['precio']
                window['imagetext3'].update(value=text)
                GPIO.output(7, GPIO.LOW) # ponemos a 0 el pin
                

            elif event=="Previous":
                idx = idx - 1 if idx > 0 else 0
                filename = datos[idx]['nombre']
                img = Image.open(filename)
                bio = io.BytesIO()
                img.save(bio, format="PNG")
                window['image'].update(data=bio.getvalue())
                
                text = 'Nombre: ' + datos[idx]['descripcion'][:30] + '...'
                window['imagetext2'].update(value=text)
                
                text = 'Precio: ' + datos[idx]['precio']
                window['imagetext3'].update(value=text)
                GPIO.output(7, GPIO.LOW) # ponemos a 0 el pin
                

            elif event=="I want it!":
                #Encender un LED
                GPIO.output(7, GPIO.HIGH) # ponemos a 1 el pin

                bio = io.BytesIO()
                img.save(bio, format="PNG")
                window['image'].update(data=bio.getvalue())
            
            
            else:
                break


GPIO.output(7, GPIO.LOW) # ponemos a 0 el pin
window.close()
# Borramos el archivo json

os.remove("resultados.json")
os.remove("imagenes/output_dict.json")




    
