import telegram
from telegram.ext import Updater, CommandHandler, ConversationHandler, CallbackQueryHandler, MessageHandler, Filters
from telegram import User, ChatAction, InlineKeyboardMarkup, InlineKeyboardButton, replymarkup
import os
import time
from time import sleep
from sense_hat import SenseHat
import urllib.request, urllib.parse
import pyautogui
from picamera import PiCamera
import shlex
import subprocess
import Adafruit_DHT
import RPi.GPIO as GPIO
from rpi_lcd import LCD

lcd = LCD()

SENSOR_DHT = Adafruit_DHT.DHT11
PIN_DHT = 4
PIN_LED = 11
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)
GPIO.setup(PIN_LED, GPIO.OUT) 

PIN_PIR = 13 
GPIO.setup(PIN_PIR, GPIO.IN, GPIO.PUD_UP) # definimos el pin entrada

from telegram.files.voice import Voice

def start(update, context):
    lcd.text("Chicken IoT",1)
    lcd.text("Inicio",2)
    
    button0 = InlineKeyboardButton(
        text = '🔎 Información sobre este bot 🔎',
        callback_data = 'info'
    )
    button1 = InlineKeyboardButton(
        text = '📚 Enlace a base de datos ChikenIoT',
        url = 'https://thingspeak.com/channels/1632614'
    )
    button2 = InlineKeyboardButton(
        text = '🐣 MODO VIGÍA. ¿NACIERON?',
        callback_data = 'vigia'
    )
    button3 = InlineKeyboardButton(
        text = '📈 GRÁFICOS THINGSPEAK',
        callback_data = 'datos'
    )  
    button4 = InlineKeyboardButton(
        text = '🎥 SOLICITUD DE VIDEO',
        callback_data = 'video'
    )
    button5 = InlineKeyboardButton(
        text = '📷 SOLICITUD DE IMAGEN',
        callback_data = 'foto'
    )

    name = update.message.from_user.username
    update.message.reply_text(
        text = f'----------------US - MIERA------------------\nSistemas Digitales Avanzados y Aplicaciones\n🐤🐣🐥🐤🐣🐥🐤🐣🐥🐤🐣🐥\n\nBuenas {name}, seleccione una acción',
        reply_markup = InlineKeyboardMarkup([
            [button0],
            [button1],
            [button2],
            [button3],
            [button4],
            [button5]
        ])
    )


def fn_info(update, context):
    lcd.text("Chicken IoT",1)
    lcd.text("Informacion",2)
    #print(update.callback_query.from_user.id) #ID del usuario que interactua
    #print(update.callback_query.message.chat.id) #ID del chat en el que se interactua. Si se está interactuando con el bot directamente este campo es el ID del usuario
    usuario_ID = update.callback_query.from_user.id
    grupo_ID = update.callback_query.message.chat.id
    texto_info = 'INFORMACIÓN SOBRE EL BOT:\n🚧🚧🚧🚧🚧🚧🚧🚧🚧🚧🚧\n\n👉Identificación: @SDAA_MIERA_bot\n\n👉Librería utilizada: python-telegram-bot\n\n👉El objetivo de este bot es facilitar una interfaz de usuario con la que poder supervisar remotamente una incubadora.'
   
    if grupo_ID > 0:
        context.bot.send_message(
            chat_id = usuario_ID,
            text = texto_info
            )
    else:
        context.bot.send_message(
            chat_id = grupo_ID,
            text = texto_info
            )
    update.callback_query.answer()


def fn_vigia(update, context):
    lcd.text("Chicken IoT",1)
    lcd.text("Modo Vigia",2)

    usuario_ID = update.callback_query.from_user.id
    grupo_ID = update.callback_query.message.chat.id    
    while (GPIO.input(PIN_PIR)) == 0: 
        
        write_key = KEY  # Key para enviar datos
        serviceurl = "https://api.thingspeak.com/update?"
        directorio = os.getcwd()+'/archivos/datos.jpg'
        Humedad, Temperatura = Adafruit_DHT.read(SENSOR_DHT, PIN_DHT)
        if Humedad is not None and Temperatura is not None:
            print("Temp={0:0.1f}C Hum={1:0.1f}%".format(Temperatura,Humedad))
            params = {"api_key": write_key, "field1": Temperatura, "field2": Humedad}
            req = urllib.parse.urlencode(params)
            url = serviceurl+req
            urllib.request.urlopen(url)
            if Temperatura < 20:
                GPIO.output(PIN_LED, GPIO.HIGH)
                print("Bombilla de calentamiento encendida")
            else:
                GPIO.output(PIN_LED, GPIO.LOW)
                print("Bombilla apagada")
        else:
            print("Falla en la lectura")

                
    texto_info = '¡Ha nacido un pollo! 🐣🐣🐣\nGrabando este hermoso mometo!! Espere un mometo...'
    bot = telegram.Bot(token=TOKEN)
    context.bot.send_message(
        chat_id = grupo_ID,
        text = texto_info
        )   
  
    directorio = os.getcwd()
    camera = PiCamera()
    camera.start_recording(directorio + '/fnnacimientoX.h264')
    sleep(5)
    camera.stop_recording()
    camera.close()
    command = shlex.split("MP4Box -add fnnacimientoX.h264 fnnacimiento.mp4")
    output = subprocess.check_output(command, stderr=subprocess.STDOUT)
    
    
    with open(f'{os.getcwd()}/fnnacimiento.mp4', 'rb') as video_file:
       bot.sendVideo(chat_id=grupo_ID,
            video=video_file,
            caption='Fecha de captura: ' + time.strftime('%H:%M:%S %d-%m-%Y', time.localtime())
            ) 
    os.remove("fnnacimiento.mp4")
    update.callback_query.answer()
    exit

       
def fn_datos(update, context):
    lcd.text("Chicken IoT",1)
    lcd.text("ThingSpeak",2)
    usuario_ID = update.callback_query.from_user.id
    grupo_ID = update.callback_query.message.chat.id
    #texto_info = 'Esta acción en vías de desarrollo, por ahora conformate con esto:'
    bot = telegram.Bot(token=TOKEN)
    
    write_key = KEY  # Key para enviar datos
    serviceurl = "https://api.thingspeak.com/update?"
    directorio = os.getcwd()+'/archivos/datos.jpg'

    Humedad, Temperatura = Adafruit_DHT.read(SENSOR_DHT, PIN_DHT)
    print("Humedad: %2.3f" %Humedad)
    print("Temperaturas: %2.3f" % (Temperatura))
    params = {"api_key": write_key, "field1": Temperatura, "field2": Humedad}
    req = urllib.parse.urlencode(params)
    url = serviceurl+req
    urllib.request.urlopen(url)
    screenshot = pyautogui.screenshot()
    screenshot.save(directorio)

    with open(f'{os.getcwd()}/archivos/datos.jpg', 'rb') as photo_file:
        bot.sendPhoto(chat_id=grupo_ID,
            photo=photo_file,
            caption='Fecha de captura: ' + time.strftime('%H:%M:%S %d-%m-%Y', time.localtime())
            )
    update.callback_query.answer()


def fn_video(update, context):
    lcd.text("Chicken IoT",1)
    lcd.text("Solicitud Video",2)
    usuario_ID = update.callback_query.from_user.id
    grupo_ID = update.callback_query.message.chat.id
    texto_info = 'Espere unos segundos... ¡Grabando!'
    bot = telegram.Bot(token=TOKEN)

    context.bot.send_message(
        chat_id = grupo_ID,
        text = texto_info
        )    
    directorio = os.getcwd()
    camera = PiCamera()
    camera.start_recording(directorio + '/fnvideoX.h264')
    sleep(5)
    camera.stop_recording()
    camera.close()
    command = shlex.split("MP4Box -add fnvideoX.h264 fnvideo.mp4")
    output = subprocess.check_output(command, stderr=subprocess.STDOUT)
    
    
    with open(f'{os.getcwd()}/fnvideo.mp4', 'rb') as video_file:
       bot.sendVideo(chat_id=grupo_ID,
            video=video_file,
            caption='Fecha de captura: ' + time.strftime('%H:%M:%S %d-%m-%Y', time.localtime())
            ) 
    os.remove("fnvideo.mp4")  
    update.callback_query.answer()


def fn_foto(update, context):
    lcd.text("Chicken IoT",1)
    lcd.text("Solicitud Imagen",2)
    usuario_ID = update.callback_query.from_user.id
    grupo_ID = update.callback_query.message.chat.id
    bot = telegram.Bot(token=TOKEN)
    directorio = os.getcwd()+'/archivos/fnfoto.jpg'
    camera = PiCamera()
    camera.resolution = (640,480)
    camera.rotation = 180
    camera.capture(directorio)
    camera.close()
    with open(f'{os.getcwd()}/archivos/fnfoto.jpg', 'rb') as photo_file:
        bot.sendPhoto(chat_id=grupo_ID,
            photo=photo_file,
           caption='Fecha de captura: ' + time.strftime('%H:%M:%S %d-%m-%Y', time.localtime())
            )
    update.callback_query.answer()


def help(update, context):
    name = update.message.from_user.username
    update.message.reply_text(f'¡Hola {name}!, para más información consulta a Javi o Nico')

if __name__ == '__main__':
    # Updater se utiliza para saber las peticiones que recive el bot por parte de los usuarios
    updater = Updater(token = "5099896331:AAF7y5AuSJ4NlE93tWny4lFoU2eUypGHN04", use_context=True)
    # dispatcher se encarga de enviar las acciones
    dp = updater.dispatcher

    # Añadimos un handler de comando
    dp.add_handler(CommandHandler('start',start))
    dp.add_handler(CommandHandler('help',help))
    
    # Para cuando se pulsan botones
    dp.add_handler(CallbackQueryHandler(pattern = 'info', callback = fn_info))
    dp.add_handler(CallbackQueryHandler(pattern = 'vigia', callback = fn_vigia))
    dp.add_handler(CallbackQueryHandler(pattern = 'datos', callback = fn_datos))
    dp.add_handler(CallbackQueryHandler(pattern = 'video', callback = fn_video))
    dp.add_handler(CallbackQueryHandler(pattern = 'foto', callback = fn_foto))

    # Con esto creamos un ciclo infinito donde se revisa continuamente las acciones de los usuarios
    updater.start_polling()
    print('El bot está en ejecución.')
    updater.idle()    
