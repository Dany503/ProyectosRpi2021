#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 23 21:36:43 2022

@author: Jaime Haldón Vallellano y Juan Manuel López Rodríguez
"""

# importamos librerias
import RPi.GPIO as GPIO
from gpiozero import Buzzer

from picamera import PiCamera

import os
import datetime as dt
import time

from twython import Twython #Librería twitter

import smtplib #Librerías email
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

APP_KEY = "xxxxxxxxxxxxxxxxxxxxxxxxxx" #Contraseñas y usuarios para la API de twitter
APP_SECRET = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
OAUTH_TOKEN = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
OAUTH_TOKEN_SECRET = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"

twitter = Twython(APP_KEY, APP_SECRET, OAUTH_TOKEN, OAUTH_TOKEN_SECRET)


#Configuración API Beebotte y creación de recursos para enviar
from beebotte import *

bclient=BBT('xxxxxxxxxxxxxxxxxxxxxxxxx','xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')

dist= Resource(bclient, 'Proyecto_Sonar', 'dist')
mensaje= Resource(bclient, 'Proyecto_Sonar', 'mensaje')
#datos_int= Resource(bclient, 'Distancia_medida', 'distancia_int')
#datos_char= Resource(bclient, 'Sucesos', 'datos_char')
#En el resource hay que indicarle el canal y donde se va a guardar.




#configuracion de resolucion e inicializacion de la camara
camara=PiCamera()
camara.resolution = (850,480)



GPIO.setmode(GPIO.BOARD) # definimos numeracion de tarjeta para los pines GPIO (Práctica 1)
GPIO.setwarnings(False)

#configuramos los pines del sonar
trigger=3 #Pin para el sensor de ultrasonido, out
echo=7 #Pin para el receptor, in
GPIO.setup(trigger, GPIO.OUT) #trigger como salida, envia la señal
GPIO.setup(echo, GPIO.IN)  #echo como entrada, recibe la señal enviada
GPIO.output(trigger,GPIO.LOW) #De momento, mandamos 0 al trigger

#configuramos el pin del buzzer
buzzer=11 #Pin para el buzzer, out
GPIO.setup(buzzer,GPIO.OUT)

#configuramos el pin del servo
servoPIN = 21
#GPIO.setmode(GPIO.BOARD)
#GPIO.setwarnings(False)
GPIO.setup(servoPIN, GPIO.OUT)
servo = GPIO.PWM(servoPIN, 50) # GPIO 21 con PWM de 50Hz
servo.start(6)#inicializacion del servo, 6:grado inicial

#configuracion notificacion via email:
direccion_fuente = "xxxxxxxxxxxxxxxxxxxxxxxx"
direccion_destino = "xxxxxxxxxxxxxxxxxxxxxxxx"
password = "xxxxxxxxxxxx"


trot=0.3 #tiempo de transicion del servo para el cambio de ángulo
trot2=0.7
cont=0 #cuenta el numero de intrusos muy cercanos

#definicion funciones de calculo de distancia sonar y grabacion del video
def calculodistancia():
    #envio valor alto por corto periodo de tiempo
    GPIO.output(trigger,GPIO.HIGH) #Mandar un alto por trigger
    time.sleep(0.00001) 
    GPIO.output(trigger,GPIO.LOW) #Lo vuelves a poner a 0
    #medimos tiempo de llegada de la señal
    while GPIO.input(echo)==0:
        tenvio=time.time()
    while GPIO.input(echo)==1:
        trecibo=time.time()
    ttotal=float(trecibo-tenvio)
    #paso el intervalo de tiempo total a distancia (cm)
    distancia=float((ttotal*34500)/2) #segun fabricante la señal viaja a 345 m/s, entre 2 pq solo quiero la distancia de ida
    return distancia

def grabo_video():
   camara.start_preview()
   if (cont==0):
       camara.start_recording('/home/pi/proyectojhv/video_sospechoso1.h264')
   if (cont==1):
       camara.start_recording('/home/pi/proyectojhv/video_sospechoso2.h264')

       

def paro_video(): 
   camara.stop_recording()
   camara.stop_preview()
   

#Mando un 0 para ver bien la gráfica#
dist.write(0) #Manda dato a beebotte, descomentar
mensaje.publish(' ')

#####Empieza el BUCLE DEL PROGRAMA#####
while True:
    
    #iteracion a 25 grados
    servo.ChangeDutyCycle(6)
    time.sleep(trot) #Esperamos unos 0.3s para que le de tiempo a rotar
    servo.ChangeDutyCycle(0) #Con 0, se está quieto. Si no, vibra mucho el servo.
    time.sleep(trot2) #Para que se esté quieto en esa posición, unos 0.7 segundos.
    rango=calculodistancia()
    print(rango)
    
    dist.publish(rango) #Manda dato a beebotte
    
    
    
    
    if (rango<10):
        mensaje.publish('Intruso Detectado. Grabando vídeo y publicando tweet')
        grabo_video()
        print("grabando video")        
        cont=cont+1
        
        GPIO.output(buzzer,GPIO.HIGH) #Para hacer pitidos con el buzzer
        time.sleep(0.2)
        GPIO.output(buzzer,GPIO.LOW)
        time.sleep(0.1)
        GPIO.output(buzzer,GPIO.HIGH)
        time.sleep(0.2)
        GPIO.output(buzzer,GPIO.LOW)
        time.sleep(0.1)
        GPIO.output(buzzer,GPIO.HIGH)
        time.sleep(0.2)
        GPIO.output(buzzer,GPIO.LOW)
        camara.capture('/home/pi/proyectojhv/intruso.jpg')

        photo = open('alerta.jpeg', 'rb')
        photo2 = open('intruso.jpg', 'rb')
        response = twitter.upload_media(media=photo) #Las vinculo como media para luego subirlas
        response2 = twitter.upload_media(media=photo2)

        twitter.update_status(status="Alerta, intruso muy cerca detectado!! Se adjunta prueba", media_ids=[response['media_id'],response2['media_id']]) #Se sube a twitter con 2 imgs
        time.sleep(4) #Para que el video dure el t de ejecución + 4 segundos
        paro_video()  #Paro el vídeo   
        mensaje.publish(' ')
        
    if (rango<20 and rango>10):
        
        mensaje.publish('Posible intruso. Publicando tweet')
        GPIO.output(buzzer,GPIO.HIGH)
        time.sleep(0.4)
        GPIO.output(buzzer,GPIO.LOW)
        time.sleep(0.3)
        GPIO.output(buzzer,GPIO.HIGH)
        time.sleep(0.4)
        GPIO.output(buzzer,GPIO.LOW)
        
        photo3 = open('precaucion.png', 'rb')
        response3 = twitter.upload_media(media=photo3)
        twitter.update_status(status="Precaución, movimiento detectado en las proximidades del recinto",  media_ids=[response3['media_id']])
        mensaje.publish(' ')
        
    if (cont>1):
        mensaje.publish('Enviando email y acabando programa')
        print("acabo programa")        
        servo.ChangeDutyCycle(0)
        server = smtplib.SMTP('smtp.gmail.com', 587) #Vincularse al email
        server.starttls()
        server.login(direccion_fuente, password)

        msg = MIMEMultipart() #Configurar el mensaje que se va a enviar
        msg['From'] = direccion_fuente
        msg['To'] = direccion_destino
        msg['Subject'] = "Aviso camara de vigilancia recinto privado"

        cuerpo_mensaje = "Se aporta video a cerca de un posible sospechoso en las inmediaciones"
        msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
        
        archivo = "video_sospechoso1.h264"
        adjunto = open(archivo, "rb")
         
        part = MIMEBase('application', 'octet-stream') #Adjuntar el archivo de vídeo
        part.set_payload((adjunto).read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', "attachment; filename= %s" % archivo)
        msg.attach(part)

        archivo = "video_sospechoso2.h264" 
        adjunto = open(archivo, "rb")
         
        part = MIMEBase('application', 'octet-stream')
        part.set_payload((adjunto).read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', "attachment; filename= %s" % archivo)
        msg.attach(part)
        
        texto = msg.as_string()

        try: #Enviar el email
            print("Enviando email")
            print(server.sendmail(direccion_fuente, direccion_destino, texto))
            mensaje.publish('Fin')
        except:
            print("Error al enviar el email")
            server.quit()
            break        
        server.quit() 
        break
    
    #iteracion a 90 grados
    servo.ChangeDutyCycle(7.5)
    time.sleep(trot)
    servo.ChangeDutyCycle(0)
    time.sleep(trot2)

    rango=calculodistancia()
    print(rango)
    
    dist.publish(rango)
    
    
    
    if (rango<10):
        mensaje.publish('Intruso Detectado. Grabando vídeo y publicando tweet')
        grabo_video()
        print("grabando video")
        cont=cont+1
        
        GPIO.output(buzzer,GPIO.HIGH)
        time.sleep(0.2)
        GPIO.output(buzzer,GPIO.LOW)
        time.sleep(0.1)
        GPIO.output(buzzer,GPIO.HIGH)
        time.sleep(0.2)
        GPIO.output(buzzer,GPIO.LOW)
        time.sleep(0.1)
        GPIO.output(buzzer,GPIO.HIGH)
        time.sleep(0.2)
        GPIO.output(buzzer,GPIO.LOW)
        camara.capture('/home/pi/proyectojhv/intruso.jpg')

        photo = open('alerta.jpeg', 'rb')
        photo2 = open('intruso.jpg', 'rb')
        response = twitter.upload_media(media=photo)
        response2 = twitter.upload_media(media=photo2)

        twitter.update_status(status="Alerta, intruso muy cerca detectado!! Se adjunta prueba", media_ids=[response['media_id'],response2['media_id']])
        time.sleep(4)
        paro_video()
        mensaje.publish(' ')

        
    if (rango<20 and rango>10):
        
        mensaje.publish('Posible intruso. Publicando tweet')
        GPIO.output(buzzer,GPIO.HIGH)
        time.sleep(0.4)
        GPIO.output(buzzer,GPIO.LOW)
        time.sleep(0.3)
        GPIO.output(buzzer,GPIO.HIGH)
        time.sleep(0.4)
        GPIO.output(buzzer,GPIO.LOW)
        
        photo3 = open('precaucion.png', 'rb')
        response3 = twitter.upload_media(media=photo3)
        twitter.update_status(status="Precaución, movimiento detectado en las proximidades del recinto",  media_ids=[response3['media_id']])
        mensaje.publish(' ')
        
    if (cont>1):
        mensaje.publish('Enviando email y acabando programa')
        print("acabo programa")
        servo.ChangeDutyCycle(0)
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(direccion_fuente, password)

        msg = MIMEMultipart()
        msg['From'] = direccion_fuente
        msg['To'] = direccion_destino
        msg['Subject'] = "Aviso camara de vigilancia recinto privado"

        cuerpo_mensaje = "Se aporta video a cerca de un posible sospechoso en las inmediaciones"
        msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
        
        archivo = "video_sospechoso1.h264"
        adjunto = open(archivo, "rb")
         
        part = MIMEBase('application', 'octet-stream')
        part.set_payload((adjunto).read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', "attachment; filename= %s" % archivo)
        msg.attach(part)

        archivo = "video_sospechoso2.h264"
        adjunto = open(archivo, "rb")
         
        part = MIMEBase('application', 'octet-stream')
        part.set_payload((adjunto).read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', "attachment; filename= %s" % archivo)
        msg.attach(part)
        
        texto = msg.as_string()

        try:
            print("Enviando email")
            print(server.sendmail(direccion_fuente, direccion_destino, texto))
            mensaje.publish('Fin')
        except:
            print("Error al enviar el email")
            server.quit()
            break        
        server.quit() 
        break
    
    #iteracion a 150 grados
    servo.ChangeDutyCycle(9)
    time.sleep(trot)
    servo.ChangeDutyCycle(0)
    time.sleep(trot2)

    rango=calculodistancia()
    print(rango)
    
    dist.publish(rango)
    
    if (rango<10):
        mensaje.publish('Intruso Detectado. Grabando vídeo y publicando tweet')
        grabo_video()
        print("grabando video")        
        cont=cont+1
        
        GPIO.output(buzzer,GPIO.HIGH)
        time.sleep(0.2)
        GPIO.output(buzzer,GPIO.LOW)
        time.sleep(0.1)
        GPIO.output(buzzer,GPIO.HIGH)
        time.sleep(0.2)
        GPIO.output(buzzer,GPIO.LOW)
        time.sleep(0.1)
        GPIO.output(buzzer,GPIO.HIGH)
        time.sleep(0.2)
        GPIO.output(buzzer,GPIO.LOW)
        camara.capture('/home/pi/proyectojhv/intruso.jpg')

        photo = open('alerta.jpeg', 'rb')
        photo2 = open('intruso.jpg', 'rb')
        response = twitter.upload_media(media=photo)
        response2 = twitter.upload_media(media=photo2)

        twitter.update_status(status="Alerta, intruso muy cerca detectado!! Se adjunta prueba", media_ids=[response['media_id'],response2['media_id']])
        time.sleep(4)
        paro_video()
        mensaje.publish(' ')
        
        
    if (rango<20 and rango>10):
        
        mensaje.publish('Posible intruso. Publicando tweet')
        GPIO.output(buzzer,GPIO.HIGH)
        time.sleep(0.4)
        GPIO.output(buzzer,GPIO.LOW)
        time.sleep(0.3)
        GPIO.output(buzzer,GPIO.HIGH)
        time.sleep(0.4)
        GPIO.output(buzzer,GPIO.LOW)
        
        photo3 = open('precaucion.png', 'rb')
        response3 = twitter.upload_media(media=photo3)
        twitter.update_status(status="Precaución, movimiento detectado en las proximidades del recinto",  media_ids=[response3['media_id']])
        mensaje.publish(' ')
        
    if (cont>1):
        mensaje.publish('Enviando email y acabando programa')
        print("acabo programa")
        servo.ChangeDutyCycle(0)
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(direccion_fuente, password)

        msg = MIMEMultipart()
        msg['From'] = direccion_fuente
        msg['To'] = direccion_destino
        msg['Subject'] = "Aviso camara de vigilancia recinto privado"

        cuerpo_mensaje = "Se aporta video a cerca de un posible sospechoso en las inmediaciones"
        msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
        
        archivo = "video_sospechoso1.h264"
        adjunto = open(archivo, "rb")
         
        part = MIMEBase('application', 'octet-stream')
        part.set_payload((adjunto).read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', "attachment; filename= %s" % archivo)
        msg.attach(part)

        archivo = "video_sospechoso2.h264"
        adjunto = open(archivo, "rb")
         
        part = MIMEBase('application', 'octet-stream')
        part.set_payload((adjunto).read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', "attachment; filename= %s" % archivo)
        msg.attach(part)
        
        texto = msg.as_string()

        try:
            print("Enviando email")
            print(server.sendmail(direccion_fuente, direccion_destino, texto))
            mensaje.publish('Fin')
        except:
            print("Error al enviar el email")
            server.quit()
            break
        server.quit()                
        break
    
    #iteracion a 90 grados
    servo.ChangeDutyCycle(7.5)
    time.sleep(trot)
    servo.ChangeDutyCycle(0)
    time.sleep(trot2)

    rango=calculodistancia()
    print(rango)
    
    dist.publish(rango)
    
    if (rango<10):
        mensaje.publish('Intruso Detectado. Grabando vídeo y publicando tweet')
        grabo_video()
        print("grabando video")
        cont=cont+1
        GPIO.output(buzzer,GPIO.HIGH)
        time.sleep(0.2)
        GPIO.output(buzzer,GPIO.LOW)
        time.sleep(0.1)
        GPIO.output(buzzer,GPIO.HIGH)
        time.sleep(0.2)
        GPIO.output(buzzer,GPIO.LOW)
        time.sleep(0.1)
        GPIO.output(buzzer,GPIO.HIGH)
        time.sleep(0.2)
        GPIO.output(buzzer,GPIO.LOW)
        
        camara.capture('/home/pi/proyectojhv/intruso.jpg')
        photo = open('alerta.jpeg', 'rb')
        photo2 = open('intruso.jpg', 'rb')
        response = twitter.upload_media(media=photo)
        response2 = twitter.upload_media(media=photo2)
        twitter.update_status(status="Alerta, intruso muy cerca detectado!! Se adjunta prueba", media_ids=[response['media_id'],response2['media_id']])
        time.sleep(4)
        paro_video()
        mensaje.publish(' ')

        
    if (rango<20 and rango>10):
        
        mensaje.publish('Posible intruso. Publicando tweet')
        GPIO.output(buzzer,GPIO.HIGH)
        time.sleep(0.4)
        GPIO.output(buzzer,GPIO.LOW)
        time.sleep(0.3)
        GPIO.output(buzzer,GPIO.HIGH)
        time.sleep(0.4)
        GPIO.output(buzzer,GPIO.LOW)
        
        photo3 = open('precaucion.png', 'rb')
        response3 = twitter.upload_media(media=photo3)
        twitter.update_status(status="Precaución, movimiento detectado en las proximidades del recinto",  media_ids=[response3['media_id']])
        mensaje.publish(' ')
        
    if (cont>1):
        mensaje.publish('Enviando email y acabando programa')
        print("acabo programa")
        servo.ChangeDutyCycle(0)
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(direccion_fuente, password)

        msg = MIMEMultipart()
        msg['From'] = direccion_fuente
        msg['To'] = direccion_destino
        msg['Subject'] = "Aviso camara de vigilancia recinto privado"

        cuerpo_mensaje = "Se aporta video a cerca de un posible sospechoso en las inmediaciones"
        msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
        
        archivo = "video_sospechoso1.h264"
        adjunto = open(archivo, "rb")
         
        part = MIMEBase('application', 'octet-stream')
        part.set_payload((adjunto).read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', "attachment; filename= %s" % archivo)
        msg.attach(part)

        archivo = "video_sospechoso2.h264"
        adjunto = open(archivo, "rb")
         
        part = MIMEBase('application', 'octet-stream')
        part.set_payload((adjunto).read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', "attachment; filename= %s" % archivo)
        msg.attach(part)
        
        texto = msg.as_string()

        try:
            print("Enviando email")
            print(server.sendmail(direccion_fuente, direccion_destino, texto))
            mensaje.publish('Fin')
        except:
            print("Error al enviar el email")
            server.quit()
            break
        server.quit()        
        break