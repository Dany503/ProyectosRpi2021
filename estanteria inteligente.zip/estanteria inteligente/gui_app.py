import tkinter as tk
from tkinter import Scrollbar, ttk
from tkinter import messagebox
import func as fc
from cidebar import camarita
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from matrizleds import enciendeled
import isbntools
from isbntools.app import *




    
def borrartabla(tabl):
    
    if(messagebox.askyesno(message="¿Desea continuar?", title="Exterminar base de datos")):#true o false
        fc.vaciaDB()
        fc.actualizaTabla(tabl)
    
    
def barra_menu(root,tabl):
    barra_menu=tk.Menu(root)
    root.config(menu = barra_menu,width = 500, height = 300)
    #print(tabl)
    menu_inicio = tk.Menu(barra_menu, tearoff=0)
    barra_menu.add_cascade(label='Operación', menu = menu_inicio)

    #menu_inicio.add_command(label='Crear registro en base de datos')# command=crear_tabla #crea base de datos
    
    menu_inicio.add_command(label='Eliminar registros en base de datos',command=lambda:borrartabla(tabl))# eliminar toda la tabla 
    
    
    menu_inicio.add_command(label='Salir', command=root.destroy)

class Frame2(tk.Frame):
    def __init__(self, root = None):
        super().__init__(root)
        self.root = root
        self.pack(side=tk.TOP,
            fill=tk.BOTH,
            expand=True)
        
    
        #self.grid_columnconfigure(0,weight=1)
        self.grid_rowconfigure(0,weight=1)
        
        #self.config(width = 870, height = 500)

        self.config(cursor='pirate')

        self.identificador_libro=None
        
        self.label_e=tk.Label(self, text='EDICIÓN')
        self.label_e.config(font=('Arial',17,'bold'))
        self.label_e.grid(row=0,column=1, padx=0, pady=0)
        
        self.imagen=tk.PhotoImage(file="LogoReducido2.png")
        self.imagen1=tk.Label(self, image=self.imagen)
        self.imagen1.grid(row=0,column=0,padx=0, pady=0)

            
        self.campos_libro()
        self.deshabilitar_campos()
        self.tabla_estanteria()
        
        #self.barra_menu()

        

    
    
        #---------------------
            
    def campos_libro(self):
        self.label_titulo=tk.Label(self, text='Título: ')
        self.label_titulo.config(font=('Arial',11,'bold'))
        self.label_titulo.grid(row=1,column=0, padx=0, pady=1)

        self.label_au=tk.Label(self, text='Autor: ')
        self.label_au.config(font=('Arial',11,'bold'))
        self.label_au.grid(row=2,column=0,padx=0, pady=1)

        self.label_c=tk.Label(self, text='Temática: ')
        self.label_c.config(font=('Arial',11,'bold'))
        self.label_c.grid(row=3,column=0,padx=0, pady=1)

        self.label_col=tk.Label(self, text='Colección: ')
        self.label_col.config(font=('Arial',11,'bold'))
        self.label_col.grid(row=4,column=0,padx=0, pady=1)

        self.label_isbn=tk.Label(self, text='ISBN: ')
        self.label_isbn.config(font=('Arial',11,'bold'))
        self.label_isbn.grid(row=5,column=0,padx=0, pady=1)

        self.label_fecha=tk.Label(self, text='Fecha: ')
        self.label_fecha.config(font=('Arial',11,'bold'))
        self.label_fecha.grid(row=6,column=0,padx=0, pady=1)

        self.label_fecha=tk.Label(self, text='Estantería [fila]: ')
        self.label_fecha.config(font=('Arial',11,'bold'))
        self.label_fecha.grid(row=7,column=0,padx=0, pady=1)

        self.label_fecha=tk.Label(self, text='Estantería [columna]: ')
        self.label_fecha.config(font=('Arial',11,'bold'))
        self.label_fecha.grid(row=8,column=0,padx=0, pady=1)

        #indicadores de la derecha (entradas)

        self.displaytitulo=tk.StringVar()
        self.entry_displaytitulo=tk.Entry(self, textvariable=self.displaytitulo)
        self.entry_displaytitulo.config(width=30, font=('Arial',10))
        self.entry_displaytitulo.grid(row=1,column=1,padx=0, pady=1)
        


        self.displayau=tk.StringVar()
        self.entry_displayau=tk.Entry(self, textvariable=self.displayau)
        self.entry_displayau.config(width=30, font=('Arial',10))
        self.entry_displayau.grid(row=2,column=1,padx=0, pady=1)

        

        #entrada escritura para genero
        self.c=tk.StringVar()
        self.entry_c=tk.Entry(self, textvariable=self.c)
        self.entry_c.config(width=30, font=('Arial',10))
        self.entry_c.grid(row=3,column=1,padx=0, pady=1)
        # otros displays
        self.col=tk.StringVar()
        self.entry_col=tk.Entry(self, textvariable=self.col)
        self.entry_col.config(width=30, font=('Arial',10))
        self.entry_col.grid(row=4,column=1,padx=0, pady=1)
        
        
        

        self.isbn=tk.StringVar()
        self.entry_isbn=tk.Entry(self, textvariable=self.isbn)#isbn
        self.entry_isbn.config(width=30, font=('Arial',10))
        self.entry_isbn.grid(row=5,column=1,padx=0, pady=1)
        #---detectar intro tecla para isbn
        
        self.entry_isbn.bind("<Return>",self.teclaintro)
        
        #.....

        self.fecha=tk.StringVar()
        self.entry_fecha=tk.Entry(self, textvariable=self.fecha)
        self.entry_fecha.config(width=30, font=('Arial',10))
        self.entry_fecha.grid(row=6,column=1,padx=0, pady=1)



        self.fila=tk.StringVar()
        self.entry_fila=tk.Entry(self, textvariable=self.fila)
        self.entry_fila.config(width=30, font=('Arial',10))
        self.entry_fila.grid(row=7,column=1,padx=0, pady=1)

        self.columna=tk.StringVar()
        self.entry_columna=tk.Entry(self, textvariable=self.columna)
        self.entry_columna.config(width=30, font=('Arial',10))
        self.entry_columna.grid(row=8,column=1,padx=0, pady=1)

        #botones
        
        self.boton_nuevo=tk.Button(self, text="Autoordenar",command=self.ordenar)
        self.boton_nuevo.config(width=20,font=('Arial',11,'bold'),
                                                fg='#DAD5D6',bg='#111119',activebackground='#A94996')
        self.boton_nuevo.grid(row=0,column=2,padx=0, pady=1)
        
        self.boton_nuevo=tk.Button(self, text="Nuevo libro",command=self.habilitar_campos)
        self.boton_nuevo.config(width=20,font=('Arial',11,'bold'),
                                                fg='#DAD5D6',bg='#158645',activebackground='#158659')
        self.boton_nuevo.grid(row=9,column=0,padx=0, pady=1)

        #--boton guardas
        self.boton_sa=tk.Button(self, text="Guardar libro", command=self.guardar_datos)
        self.boton_sa.config(width=20,font=('Arial',11,'bold'),
                                                fg='#DAD5D6',bg='#158695',activebackground='#158699')
        self.boton_sa.grid(row=9,column=1,padx=0, pady=1)
        #---------boton cancelar
        self.boton_d=tk.Button(self, text="Cancelar", command=self.deshabilitar_campos)
        self.boton_d.config(width=20,font=('Arial',11,'bold'),
                                                fg='#DAD5D6',bg='#D58645',activebackground='#D58659')
        self.boton_d.grid(row=9,column=2,padx=0, pady=1)

        #---botones de abajo
        #
        #editar
        self.boton_edi=tk.Button(self, text="Editar",command=self.editar_libro)
        self.boton_edi.config(width=20,font=('Arial',11,'bold'),
                                                fg='#DAD5D6',bg='#158645',activebackground='#158659')
        self.boton_edi.grid(row=11,column=0,padx=0, pady=1)
        #eliminar
        self.boton_elimina=tk.Button(self, text="Eliminar", command=self.eliminar_libros)
        self.boton_elimina.config(width=20,font=('Arial',11,'bold'),
                                                fg='#DAD5D6',bg='#D58645',activebackground='#D58659')
        self.boton_elimina.grid(row=11,column=1,padx=0, pady=1)
        #boton led

        self.boton_edil=tk.Button(self, text="Indicar LED",command=self.encender)
        self.boton_edil.config(width=20,font=('Arial',11),
                                                fg='#DAD5D6',bg='#157205',activebackground='#158699')
        self.boton_edil.grid(row=11,column=2,padx=0, pady=1)

    def ordenar(self):
        fc.ordenarTodo()
        fc.actualizaTabla(self.tabla)
        
    def teclaintro(self,event):
        try:
            isbn=self.isbn.get()
            meta_dict = meta(isbn, service='goob')
            titulo=meta_dict["Title"]#
            autor=",".join(meta_dict["Authors"])
            isbnn=meta_dict["ISBN-13"]
            ffecha=meta_dict["Year"]

            self.displaytitulo.set(titulo)
            self.displayau.set(autor)
            
            self.isbn.set(isbnn)
            self.fecha.set(ffecha)
        except:
            
            tit='Edición de datos'
            mensaje='ISBN no identificado'
            messagebox.showerror(tit,mensaje)
        
        
    #funciones para des/habilitar registro de libro nuevo
    def habilitar_campos(self):
        self.imagen=tk.PhotoImage(file="camara2.png")
        self.imagen1=tk.Label(self, image=self.imagen)
        self.imagen1.grid(row=0,column=0,padx=0, pady=0)
        #aquí dentro se habilitaría inicio de leer camara el código de barras
        try:
            meta_dict=camarita()
            
            

            titulo=meta_dict["Title"]#esto seria lo que devolvera la función que lee la camara
            autor=",".join(meta_dict["Authors"])
            isbnn=meta_dict["ISBN-13"]
            ffecha=meta_dict["Year"]

            self.displaytitulo.set(titulo)
            self.displayau.set(autor)
            
            self.isbn.set(isbnn)
            self.fecha.set(ffecha)
        except:
            
            tit='Edición de datos'
            mensaje='ISBN no identificado'
            messagebox.showerror(tit,mensaje)
            
            
        
        
         
        self.entry_c.config(state='normal')
        self.entry_col.config(state='normal')
        self.entry_displaytitulo.config(state='normal')
        self.entry_displayau.config(state='normal')
        self.entry_isbn.config(state='normal')
        self.entry_fecha.config(state='normal')
        self.entry_fila.config(state='normal')
        self.entry_columna.config(state='normal')

        self.boton_sa.config(state='normal')
        self.boton_d.config(state='normal')
        self.boton_edi.config(state='disabled')
        self.boton_elimina.config(state='disabled')
        
        

    def deshabilitar_campos(self):
        self.imagen=tk.PhotoImage(file="LogoReducido2.png")
        self.imagen1=tk.Label(self, image=self.imagen)
        self.imagen1.grid(row=0,column=0,padx=0, pady=0)
        
        self.identificador_libro=None

        self.c.set('')#vaciamos el recuadro que se rellenó
        self.displaytitulo.set('')
        self.displayau.set('')
        self.col.set('')
        self.isbn.set('')
        self.fecha.set('')
        self.fila.set('')
        self.columna.set('')
        
         


        self.entry_c.config(state='disabled')
        self.entry_displayau.config(state='disabled')
        self.entry_displaytitulo.config(state='disabled')
        self.entry_fecha.config(state='disabled')
        self.entry_isbn.config(state='disabled')
        self.entry_col.config(state='disabled')
        self.entry_fila.config(state='disabled')
        self.entry_columna.config(state='disabled')


        self.boton_sa.config(state='disabled')
        self.boton_d.config(state='disabled')

        self.boton_edi.config(state='normal')
        self.boton_elimina.config(state='normal')




    def guardar_datos(self):
        #aqui inserta el nuevo libro en la base de datos
        

        if self.identificador_libro ==None:
            if (fc.anadirLibro(self.isbn.get(),self.displaytitulo.get(),self.displayau.get(),self.col.get(),self.c.get(),self.fecha.get(),self.fila.get(),self.columna.get())):
                fc.actualizaTabla(self.tabla)
            else:
                messagebox.showerror('Error','No se ha podido añadir a la base de datos')
        else:
            if (fc.editarLibro(self.identificador_libro,self.isbn.get(),self.displaytitulo.get(),self.displayau.get(),self.col.get(),self.c.get(),self.fecha.get(),self.fila.get(),self.columna.get())):
                fc.actualizaTabla(self.tabla)
            else:
                messagebox.showerror('Error','No se ha podido editar la base de datos')
        

        self.deshabilitar_campos()
        





    def tabla_estanteria(self):
        '''self.lista_libros=listar() #lista de peliculas que devuelve desde la base de datos
        self.lista_libros.reverse()
        '''
        self.tabla=ttk.Treeview(self, column=('Título','Autor','Temática','Colección','ISBN','Fecha','Estante fila','Estante col'))
        self.tabla.grid(row=10, column=0, columnspan=9,sticky='nse')
       
        self.scroll=ttk.Scrollbar(self, orient='vertical', command=self.tabla.yview) #deslizador para tabla cuando no se pueden visualizar todos
        self.scroll.grid(row=10,column=9,sticky='nse')

        

        self.tabla.heading('#0', text='Identificador')
        self.tabla.heading('#1', text='Titulo')
        self.tabla.heading('#2', text='Autor')
        self.tabla.heading('#3', text='Temática')
        self.tabla.heading('#4', text='Colección')
        self.tabla.heading('#5', text='ISBN')
        self.tabla.heading('#6', text='Fecha')
        self.tabla.heading('#7', text='Estante fila')
        self.tabla.heading('#8', text='Estante col')

        #---Mostrar elementos que hay en estantería
        #self.tabla.insert('',0,text='1',values=('Ulisses Moore y los guardianes de piedra','Pierdomenico','Fantasía','Ulisses Moore','675645456454','6 5 21'))
        #self.tabla.insert('',0,text='2',values=('Ulisses Moore y la casa de los espejos','Pierdomenico','Fantasía','Ulisses Moore','67577776454','6 5 21'))
        fc.actualizaTabla(self.tabla)
        

        

    def encender(self):
        try:
            #primero recupero datos de la tabla
            self.identificador_libro= self.tabla.item(self.tabla.selection())['text']
            self.titulo_libro= self.tabla.item(self.tabla.selection())['values'][0]
            self.autor_libro= self.tabla.item(self.tabla.selection())['values'][1]
            self.genero_libro= self.tabla.item(self.tabla.selection())['values'][2]
            self.mi_coleccion=self.tabla.item(self.tabla.selection())['values'][3]
            self.mi_isbn=self.tabla.item(self.tabla.selection())['values'][4]
            self.mi_fecha=self.tabla.item(self.tabla.selection())['values'][5]
            self.mi_fila=self.tabla.item(self.tabla.selection())['values'][6]
            self.mi_col=self.tabla.item(self.tabla.selection())['values'][7]
            
            #--

            
            
            
            try:
                mi_col=int(self.mi_col)
                mi_fil=int(self.mi_fila)
                
                
                enciendeled(mi_fil,mi_col)
                
                
            except:
                tit='Error led'
                mensaje='Error led'
                messagebox.showerror(tit,mensaje)


        except:
            tit='Edición de datos'
            mensaje='No ha seleccionado ningún  registro'
            messagebox.showerror(tit,mensaje)

    def editar_libro(self):
        try:
            #primero recupero datos de la tabla
            self.identificador_libro= self.tabla.item(self.tabla.selection())['text']
            self.titulo_libro= self.tabla.item(self.tabla.selection())['values'][0]
            self.autor_libro= self.tabla.item(self.tabla.selection())['values'][1]
            self.genero_libro= self.tabla.item(self.tabla.selection())['values'][2]
            self.mi_coleccion=self.tabla.item(self.tabla.selection())['values'][3]
            self.mi_isbn=self.tabla.item(self.tabla.selection())['values'][4]
            self.mi_fecha=self.tabla.item(self.tabla.selection())['values'][5]
            self.mi_fila=self.tabla.item(self.tabla.selection())['values'][6]
            self.mi_col=self.tabla.item(self.tabla.selection())['values'][7]
            
            #----
             
            #la edición será manual todo
            self.entry_displayau.config(state='normal')
            self.entry_displaytitulo.config(state='normal')
            self.entry_c.config(state='normal')
            self.entry_col.config(state='normal')
            self.entry_isbn.config(state='normal')
            self.entry_fecha.config(state='normal')
            self.entry_fila.config(state='normal')
            self.entry_columna.config(state='normal')

            self.boton_sa.config(state='normal')
            self.boton_d.config(state='normal')

            self.entry_displaytitulo.delete(0,len(self.entry_displaytitulo.get()))
            self.entry_displayau.delete(0,len(self.entry_displayau.get()))
            self.entry_c.delete(0,len(self.entry_c.get()))
            self.entry_col.delete(0,len(self.entry_col.get()))
            self.entry_isbn.delete(0,len(self.entry_isbn.get()))
            self.entry_fecha.delete(0,len(self.entry_fecha.get()))
            self.entry_columna.delete(0,len(self.entry_columna.get()))
            self.entry_fila.delete(0,len(self.entry_fila.get()))

            self.entry_displaytitulo.insert(0,self.titulo_libro)
            self.entry_displayau.insert(0,self.autor_libro)
            self.entry_c.insert(0,self.genero_libro)
            self.entry_col.insert(0,self.mi_coleccion)
            self.entry_isbn.insert(0,self.mi_isbn)
            self.entry_fecha.insert(0,self.mi_fecha)
            self.entry_columna.insert(0,self.mi_col)
            self.entry_fila.insert(0,self.mi_fila)

            


        except:
            tit='Edición de datos'
            mensaje='No ha seleccionado ningún  registro'
            messagebox.showerror(tit,mensaje)

    def eliminar_libros(self):
        try:
            self.identificador_libro= self.tabla.item(self.tabla.selection())['text']
            #eliminar(self.identificador_libro)
            fc.eliminarLibro(self.identificador_libro)
            fc.actualizaTabla(self.tabla)

            #despues de eliminar hay que actualizar la tabla
            #self.tabla_estanteria()
            self.identificador_libro=None #reiniciar el identificador

        except:
            tit='Edición de datos'
            mensaje='No ha seleccionado ningún  registro'
            messagebox.showerror(tit,mensaje)

            

'''class FrameLogin(tk.Frame):
    def __init__(self, root = None):
        super().__init__(root)
        self.root = root
        self.pack(side=tk.TOP,
            fill=tk.BOTH,
            expand=True)
        self.grid_columnconfigure(0,weight=1)
        self.grid_rowconfigure(0,weight=1)'''
