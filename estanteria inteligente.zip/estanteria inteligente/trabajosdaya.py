import tkinter as tk
from tkinter import Frame, ttk
from tkinter.constants import BOTH, HORIZONTAL, LEFT, VERTICAL
from gui_app import Frame2, barra_menu#,FrameLogin
from gui_orden import Frame3
import RPi.GPIO as GPIO
import func as fc

from matrizleds import inicio_leds

def main():
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BOARD) # definimos la numeracion
    inicio_leds()
    root1 = tk.Tk()
    root1.title('Estantería')
    #root1.iconbitmap('logo.ico')
    root1.geometry("1000x600+0+0")
    root1.resizable(1,1)
    #Se mostrarán 2 pestañas
    tab_control = ttk.Notebook(root1)
    tab1=ttk.Frame(tab_control)
    tab2=ttk.Frame(tab_control)
    
    tab_control.add(tab1, text='Edicion')
    tab_control.add(tab2, text='Busqueda')
    
    main_frame=tab1

    my_canvas=tk.Canvas(main_frame)
    my_canvas.pack(side=LEFT,fill=BOTH, expand=1)

    scroll_ventana=ttk.Scrollbar(main_frame,orient=VERTICAL,command=my_canvas.yview) #deslizador
    scroll_ventana.pack(side=tk.RIGHT,fill=tk.Y)

    scroll_ventana_hor=ttk.Scrollbar(main_frame,orient=HORIZONTAL,command=my_canvas.xview) #deslizador
    scroll_ventana_hor.pack(side=tk.BOTTOM,fill=tk.X)
    
    my_canvas.configure(yscrollcommand=scroll_ventana.set, xscrollcommand=scroll_ventana_hor.set)
    my_canvas.bind('<Configure>', lambda e: my_canvas.configure(scrollregion=my_canvas.bbox("all")))

    second_frame=Frame2(root=my_canvas)
    tabl=second_frame.tabla
    
    my_canvas.create_window((0,0),window=second_frame, anchor='nw')
#-----------------------------------------------------------------------------
    #second_frame=Frame2(root = tab1)
    #Frame3(root=tab2)
    
    main_frame2=tab2

    my_canvas2=tk.Canvas(main_frame2)
    my_canvas2.pack(side=LEFT,fill=BOTH, expand=1)

    scroll_ventana2=ttk.Scrollbar(main_frame2,orient=VERTICAL,command=my_canvas2.yview) #deslizador
    scroll_ventana2.pack(side=tk.RIGHT,fill=tk.Y)

    scroll_ventana_hor2=ttk.Scrollbar(main_frame2,orient=HORIZONTAL,command=my_canvas2.xview) #deslizador
    scroll_ventana_hor2.pack(side=tk.BOTTOM,fill=tk.X)
    
    my_canvas2.configure(yscrollcommand=scroll_ventana2.set, xscrollcommand=scroll_ventana_hor2.set)
    my_canvas2.bind('<Configure>', lambda e: my_canvas2.configure(scrollregion=my_canvas.bbox("all")))

    second_frame2=Frame3(root=my_canvas2)
    
    my_canvas2.create_window((0,0),window=second_frame2, anchor='nw')
    #-----------------------------------
    barra_menu(root1,tabl)
    

    tab_control.pack(expand=1, fill='both')


    root1.mainloop()#refresca aplicación
    #root1.quit()

if __name__ == '__main__':
    fc.iniciaDaemon()
    main()
