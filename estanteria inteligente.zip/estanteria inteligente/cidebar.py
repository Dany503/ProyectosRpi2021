from picamera import PiCamera
from time import sleep
from pyzbar import pyzbar
from PIL import Image
import cv2
import isbntools
from isbntools.app import *
import matplotlib.pyplot as plt
import matplotlib.image as mpimg

import numpy as np




def autocrop(image, threshold=0):
    """Crops any edges below or equal to threshold
    Crops blank image to 1x1.
    Returns cropped image.
    """
    if len(image.shape) == 3:
        flatImage = np.max(image, 2)
    else:
        flatImage = image
    assert len(flatImage.shape) == 2

    rows = np.where(np.max(flatImage, 0) > threshold)[0]
    if rows.size:
        cols = np.where(np.max(flatImage, 1) > threshold)[0]
        image = image[cols[0]: cols[-1] + 1, rows[0]: rows[-1] + 1]
    else:
        image = image[:1, :1]

    return image



def camarita():
    try:
        camera = PiCamera()
        
        camera.sharpness = 100
        #camera.awb_mode = 'sunlight'
        camera.resolution = (2592, 1944)
        camera.exposure_mode ='night'
        camera.framerate = 15
        camera.rotation = 180
        camera.start_preview(fullscreen=False, window=(30,30,320,240))
        
        for i in range(1,3):
            print(3-i)
            sleep(1)
        
        camera.capture('/home/pi/imagen.jpg')
        camera.stop_preview()
        camera.close()
        
        #image = cv2.imread('/home/pi/a.jpeg')
        #image = cv2.imread('/home/pi/imagen.jpeg')
        image = mpimg.imread('/home/pi/imagen.jpg')
        crop = autocrop(image, 165)
        
        d = pyzbar.decode(crop)
       
        
        #print(d)
        #print('---')
        isbn = d[0].data
        isbn= isbn.decode('utf-8')
        #print(isbn)
        meta_dict = meta(isbn, service='goob')
    #print(meta_dict)
    except:
        pass
    return meta_dict
'''if __name__ == "__main__":
    meta_dict=camarita()
    a=meta_dict["Year"]'''
