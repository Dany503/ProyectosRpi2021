#Aquí se aladirán los import necesarios para el funcionamiento de las funciones
from turtle import pos
import pandas as pd
from datetime import date
from isbntools.app import *
import os
import threading
import time
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

CuentaCorreo="XXXXXXX@gmail.com"
ContrasenaCorreo="XXXXXXXXXX"

numfil=8
numcol=8
diasEntreRecordatorios=7



def buscarSitio(titulo:str,autor:str,coleccion:str,tematica:str,df:pd.DataFrame):
    '''Requiere un libro definido por su título, autor y colección, y un dataframe que contiene la base de datos.\n
    Devuelve una lista con las coordenadas del estante correspondiente al libro, con formato:\n
    ret[0]->fila\n
    ret[1]->columna'''
    dn=pd.DataFrame([], columns=["isbn","titulo","autor","coleccion","tematica","fecha","adquirido","estanteFil","estanteCol","prestado","recordatorio","fecharec"], index=[])
    dn.loc[0,"titulo"]=titulo
    dn.loc[0,"autor"]=autor
    dn.loc[0,"coleccion"]=coleccion
    dn.loc[0,"tematica"]=tematica
    df=df.append(dn,ignore_index=True)
    newind=df.index[-1]
    df.sort_values(by=['tematica','autor','coleccion','titulo'],inplace=True)
    #print(df)
    posind=df.index.get_loc(newind)
    if posind==0:
        filant=0
        colant=0
    else:
        filant=int(df['estanteFil'].iloc[posind-1])
        colant=int(df['estanteCol'].iloc[posind-1])
    if posind==len(df.index)-1:
        colsig=numcol-1
        filsig=numfil-1
    else:
        colsig=int(df['estanteFil'].iloc[posind+1])
        filsig=int(df['estanteCol'].iloc[posind+1])
    sig=colsig+filsig*numfil
    #print(sig)
    ant=filant+colant*numfil
    #print(ant)
    es=(sig+ant)//2
    #print(es)
    fil=es % numcol
    col=es//numcol
    ret=[]
    ret.append(fil)
    ret.append(col)
    return ret

def ordenarTodo():
    '''Ordena todos los libros almacenados en la base de datos.'''
    df=pd.read_csv('db.csv',dtype=str)
   
    df.sort_values(by=['tematica','autor','coleccion','titulo'],inplace=True,ignore_index=True)
    maxEst=numfil*numcol-1
    est=(float(maxEst)+1)/(float(len(df))+1)*(df.index+1)+0.5
    df['estanteCol']=(est % numcol).astype(int)
    df['estanteFil']=(est // numcol).astype(int)
    df.to_csv('db.csv',index=False)
    
def vaciaDB():
    '''Elimina la base de datos.'''
    os.remove('db.csv')

def creaDB():
    '''Crea la base de datos si no existe'''
    if not os.path.isfile('db.csv'):
        f = open("db.csv", "w")
        f.write("isbn,titulo,autor,coleccion,tematica,fecha,adquirido,estanteFil,estanteCol,prestado,recordatorio,fecharec\n")
        f.close()
        

def anadirLibro(isbn:str,titulo:str,autor:str,coleccion:str,tematica:str,fecha:str,estanteFil:int,estanteCol:int):
    '''Añade un libro a la base de datos. Requiere los valores necesarios para la base de datos.\n
    Devuelve un valor booleano True si se han podido guardar los datos y False en caso contrario.'''
    try:
        creaDB()
        df=pd.DataFrame([], columns=["isbn","titulo","autor","coleccion","tematica","fecha","adquirido","estanteFil","estanteCol","prestado","recordatorio","fecharec"], index=[])
        db=pd.read_csv('db.csv',dtype=str)
        df.loc[0,"isbn"]=isbn
        df.loc[0,"titulo"]=titulo
        df.loc[0,"autor"]=autor
        df.loc[0,"coleccion"]=coleccion
        df.loc[0,"tematica"]=tematica
        df.loc[0,"fecha"]=fecha
        df.loc[0,"adquirido"]=date.today().strftime("%d/%m/%Y")
        df.loc[0,"prestado"]=""
        est=buscarSitio(titulo,autor,coleccion,tematica,db)
        if estanteFil!="":
            df.loc[0,"estanteFil"]=estanteFil
            #print('manual:'+str(estanteFil))
        else:
            df.loc[0,"estanteFil"]=est[0]
            #print('manual2:'+str(est[0]))
        if estanteCol!="":
            df.loc[0,"estanteCol"]=estanteCol
            #print('manual col:'+str(estanteCol))
        else:
            df.loc[0,"estanteCol"]=est[1]
            #print('manual2 col:'+str(est[1]))
        df=df.append(db,ignore_index=True)
        df.to_csv('db.csv',index=False)
        return True
    except:
        return False


def editarLibro(id,isbn:str,titulo:str,autor:str,coleccion:str,tematica:str,fecha:str,estanteFil:int,estanteCol:int):
    '''Edita un libro de la base de datos. Requiere los valores necesarios para la base de datos.\n
    Devuelve un valor booleano True si se han podido guardar los datos y False en caso contrario.'''
    try:
        df=pd.read_csv('db.csv',dtype=str)
        id=int(id)
        df.loc[id,"isbn"]=isbn
        df.loc[id,"titulo"]=titulo
        df.loc[id,"autor"]=autor
        df.loc[id,"coleccion"]=coleccion
        df.loc[id,"tematica"]=tematica
        df.loc[id,"fecha"]=fecha
        df.loc[id,"adquirido"]=date.today().strftime("%d/%m/%Y")
        df.loc[id,"estanteFil"]=estanteFil
        df.loc[id,"estanteCol"]=estanteCol
        df.to_csv('db.csv',index=False)
        return True
    except:
        return False

def eliminarLibro(id:int):
    '''Elimina un libro de la base de datos. Requiere la ID del libro a eliminar.\n
    Devuelve un valor booleano True si se han podido eliminar los datos y False en caso contrario.'''
    try:
        df=pd.read_csv('db.csv',dtype=str)
        id=int(id)
        df=df.drop(id)
        df.to_csv('db.csv',index=False)
        return True
    except:
        return False

def buscaLibro(isbn:str,titulo:str,autor:str,coleccion:str,tematica:str,tab):
    '''Busca libros en la base de datos. Requiere los datos de los libros a buscar.\n
    Devuelve un dataframe con los datos de cada libro encontrado.'''
    df=pd.read_csv('db.csv',dtype=str)
    dfl=df.copy()
    try:
        if(isbn!=""): #si se han introducido datos en el campo
            df.dropna(subset = ["isbn"], inplace=True) #Elimina libros con el campo en blanco
            dfl=df.copy() #recorta el dataframe para comparar
            dfl["isbn"] = df["isbn"].str.lower() #En principio el ISBN es un campo numérico. No obstante, la base de datos admite strings, así que no está de más en caso de que se utilice de otra forma.
            df= df[dfl['isbn'].str.contains(isbn.lower())] #La comparación en lower case permite ignorar el uso de mayúsculas

        if(titulo!=""): #si se han introducido datos en el campo
            df.dropna(subset = ["titulo"], inplace=True) #Elimina libros con el campo en blanco
            dfl=df.copy() #recorta el dataframe para comparar
            dfl["titulo"] = df["titulo"].str.lower() 
            df= df[dfl['titulo'].str.contains(titulo.lower())] 

        if(autor!=""): #si se han introducido datos en el campo
            df.dropna(subset = ["autor"], inplace=True) #Elimina libros con el campo en blanco
            dfl=df.copy() #recorta el dataframe para comparar
            dfl["autor"] = df["autor"].str.lower() 
            df= df[dfl['autor'].str.contains(autor.lower())] 

        if(coleccion!=""): #si se han introducido datos en el campo
            df.dropna(subset = ["coleccion"], inplace=True) #Elimina libros con el campo en blanco
            dfl=df.copy() #recorta el dataframe para comparar
            dfl["coleccion"] = df["coleccion"].str.lower() 
            df= df[dfl['coleccion'].str.contains(coleccion.lower())] 

        if(tematica!=""): #si se han introducido datos en el campo
            df.dropna(subset = ["tematica"], inplace=True) #Elimina libros con el campo en blanco
            dfl=df.copy() #recorta el dataframe para comparar
            dfl["tematica"] = df["tematica"].str.lower() 
            df= df[dfl['tematica'].str.contains(tematica.lower())] 

    
        for index, row in df.iterrows():
            tab.insert('',0,text=str(index),values=(row['titulo'],row['autor'],row['tematica'],row['coleccion'],row['isbn'],row['fecha'],str(row['estanteFil'])+'/'+str(row['estanteCol']),row['prestado']))
        return True
    except Exception as e:
        print(e)
        return False

def enciendeEstante(fil,col):
    '''UNUSED\nIlumina el estante correspondiente a un libro almacenado en la base de datos a partir de su id\n UNUSED\n
    ToDo: leer la base de datos e iluminar'''
    ret=[0,0]
    pass

def actualizaTabla(tab):
    '''Actualiza una tabla de tipo treeview con los datos almacenados en la base de datos.'''
    for element in tab.get_children():
        tab.delete(element)
    try:
        df=pd.read_csv('db.csv',dtype=str)
        for index, row in df.iterrows():
            tab.insert('',0,text=str(index),values=(row['titulo'],row['autor'],row['tematica'],row['coleccion'],row['isbn'],row['fecha'],row['estanteFil'],row['estanteCol']))
    except:
        pass
    pass


def indicesTabla():
    '''UNUSED\n Devuelve la lista de índices de la tabla\n UNUSED'''

    return 0

def leeTabla(indice:int):
    '''UNUSED\n Devuelve los datos de un elemento de la tabla\n UNUSED'''
    #ToDo:
    ret=[]
    ret[0]='Ulisses Moore y la casa de los espejos'
    ret[1]='Pierdomenico'
    ret[2]='Fantasía'
    ret[3]='Ulisses Moore'
    ret[4]='67577776454'
    ret[5]='6 5 21'
    return ret

def iniciaDaemon():
    '''Inicia el hilo concurrente para la gestión y envío de correos electrónicos.'''
    x = threading.Thread(target=daemonCorreo,daemon=True)
    x.start()

def daemonCorreo():
    '''Bucle infinito que revisa y gestiona el envío de correos. Usar únicamente en un daemon para evitar problemas.'''
    while(True):
        if os.path.isfile('db.csv'):
            db=pd.read_csv('db.csv',dtype=str)
            db['fecharec']=pd.to_datetime(db['fecharec'])

            df = db.dropna(subset=['fecharec'])
            df.loc['fecharec']=pd.to_datetime(df['fecharec'])
            df=df.loc[df['fecharec'] <= pd.to_datetime(str(pd.Timestamp.now()))]
            for index in df.index:
                db.loc[index,'fecharec']=db['fecharec'][index]+pd.Timedelta(diasEntreRecordatorios, "d")
                f = open("mail"+db['recordatorio'][index]+".txt")
                mailCont=f.read()
                f.close()
                f = open("mailend.txt")
                mailCont=mailCont+db['fecharec'][index].strftime('%d/%m/%Y')+"\t\t\t"+db['titulo'][index]+"\n"+f.read()
                f.close()

                try:
                    enviaCorreo(db['prestado'][index],"Recordatorio préstamo "+db['titulo'][index],mailCont)
                except:
                    print("msg error to "+db['prestado'][index])
                if int(db['recordatorio'][index])<2:
                    db.loc[index,'recordatorio']=str(int(db.loc[index,'recordatorio'])+1)
            db.to_csv('db.csv',index=False)
        time.sleep(60)

def enviaCorreo(msto,mssub,mstext):
    '''Envia mstext como un email a msto con asunto mssub'''
    try:
        server=smtplib.SMTP('smtp.gmail.com',587)
        #print(0)
        server.starttls()
        #print(1)
        server.login(CuentaCorreo,ContrasenaCorreo)
        #print(2)
        msg=MIMEMultipart()
        msg['From']=CuentaCorreo
        msg['To']=msto
        msg['Subject']=mssub
        msg.attach(MIMEText(mstext,'plain'))
        texto=msg.as_string()
        server.sendmail(CuentaCorreo,msto,texto)
        print(4)
        server.quit()
    except Exception as e:
        server.quit()
        raise Exception(e)

    

def prestaLibro(id,prestado):
    '''Marca el libro determinado por su id como prestado al email definido en prestado'''
    df=pd.read_csv('db.csv',dtype=str)
    id=int(id)

    flim=(pd.Timestamp.now()+pd.Timedelta(diasEntreRecordatorios, "d")).strftime('%Y-%m-%d')
    f = open("mail0.txt")
    mailCont=f.read()
    f.close()
    f = open("mailend.txt")
    mailCont=mailCont+flim+"\t\t\t"+df['titulo'][id]+"\n"+f.read()
    f.close()

    enviaCorreo(prestado,"Préstamo "+df['titulo'][id],mailCont)
    if(pd.isnull(df.loc[id,"prestado"])):
        df.loc[id,"prestado"]=prestado
        df.loc[id,"recordatorio"]=1
        df.loc[id,"fecharec"]=flim
        df.to_csv('db.csv',index=False)
        return True
    else:
        return False
    
def devuelveLibro(id):
    '''Marca el libro determinado por su id como devuelto'''
    df=pd.read_csv('db.csv',dtype=str)
    id=int(id)

    if(pd.isnull(df.loc[id,"prestado"])):
        return False
    else:
        f = open("maildev.txt")
        mailCont=f.read()
        f.close()
        f = open("mailend.txt")
        mailCont=mailCont+df['titulo'][id]+"\n"+f.read()
        f.close()

        enviaCorreo(df.loc[id,"prestado"],"Devolución préstamo "+df['titulo'][id],mailCont)

        df.loc[id,"prestado"]=""
        df.loc[id,"recordatorio"]=""
        df.loc[id,"fecharec"]=""
        df.to_csv('db.csv',index=False)
        return True