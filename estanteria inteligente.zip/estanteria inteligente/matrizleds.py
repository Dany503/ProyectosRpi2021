# importamos el modulo de GPIO
import RPi.GPIO as GPIO
import time
from tkinter import messagebox


'''
rasp<--matriz
8<--0 , 9
10<--D
12<--F
16<--3
18<--A
22<-1
24<-G
26<-H
------
32<-2
36<-5
38<-E
40<-7
37<-C
35<-B
33<-6
31<-4


'''

def inicio_leds():
    
    GPIO.setup(8, GPIO.OUT) # definimos el pin como salida
    GPIO.setup(10, GPIO.OUT)
    GPIO.setup(12, GPIO.OUT)
    GPIO.setup(16, GPIO.OUT)
    GPIO.setup(18, GPIO.OUT)
    GPIO.setup(22, GPIO.OUT)
    GPIO.setup(24, GPIO.OUT)
    GPIO.setup(26, GPIO.OUT)

    GPIO.setup(32, GPIO.OUT)
    GPIO.setup(36, GPIO.OUT)
    GPIO.setup(38, GPIO.OUT)
    GPIO.setup(40, GPIO.OUT)
    GPIO.setup(37, GPIO.OUT)
    GPIO.setup(35, GPIO.OUT)
    GPIO.setup(33, GPIO.OUT)
    GPIO.setup(31, GPIO.OUT) 


    GPIO.output(8, GPIO.LOW) # 1 (0)
    GPIO.output(10, GPIO.HIGH)
    GPIO.output(12, GPIO.HIGH)
    GPIO.output(16, GPIO.LOW)
    GPIO.output(18, GPIO.HIGH)#A
    GPIO.output(22, GPIO.LOW)
    GPIO.output(24, GPIO.HIGH)
    GPIO.output(26, GPIO.HIGH)

    GPIO.output(32, GPIO.LOW)
    GPIO.output(36, GPIO.LOW)
    GPIO.output(38, GPIO.HIGH)
    GPIO.output(40, GPIO.LOW)
    GPIO.output(37, GPIO.HIGH)
    GPIO.output(35, GPIO.HIGH)#B
    GPIO.output(33, GPIO.LOW)
    GPIO.output(31, GPIO.LOW)

l1=8
D=10
F=12
l4=16
A=18
l2=22
G=24
H=26

l3=32
l6=36
E=38
l8=40
C=37
B=35
l7=33
l5=31
def enciendeled(x,y):
    #fila
    if x==0:
      GPIO.output(l1,GPIO.HIGH)
    else:
      GPIO.output(l1,GPIO.LOW)
      
    if x==1:
      GPIO.output(l2,GPIO.HIGH)
    else:
      GPIO.output(l2,GPIO.LOW)
    
    if x==2:
      GPIO.output(l3,GPIO.HIGH)
    else:
      GPIO.output(l3,GPIO.LOW)
    
    if x==3:
      GPIO.output(l4,GPIO.HIGH)
    else:
      GPIO.output(l4,GPIO.LOW)
    
    if x==4:
      GPIO.output(l5,GPIO.HIGH)
    else:
      GPIO.output(l5,GPIO.LOW)
    
    if x==5:
      GPIO.output(l6,GPIO.HIGH)
    else:
      GPIO.output(l6,GPIO.LOW)
    
    if x==6:
      GPIO.output(l7,GPIO.HIGH)
    else:
      GPIO.output(l7,GPIO.LOW)
    
    if x==7:
      GPIO.output(l8,GPIO.HIGH)
    else:
      GPIO.output(l8,GPIO.LOW)
      
    #columnas
    if y==0:
      
      GPIO.output(A,GPIO.LOW)
    else:
      GPIO.output(A,GPIO.HIGH)
      
    if y==1:
      GPIO.output(B,GPIO.LOW)
    else:
      
      GPIO.output(B,GPIO.HIGH)
      
    if y==2:
      
      GPIO.output(C,GPIO.LOW)
    else:
      GPIO.output(C,GPIO.HIGH)
      
    if y==3:
      GPIO.output(D,GPIO.LOW)
    else:     
      GPIO.output(D,GPIO.HIGH)
      
    if y==4:
      
      GPIO.output(E,GPIO.LOW)
    else:
      GPIO.output(E,GPIO.HIGH)
      
    if y==5:
      
      GPIO.output(F,GPIO.LOW)
    else:
      GPIO.output(F,GPIO.HIGH)
      
    if y==6:
      GPIO.output(G,GPIO.LOW)
    else:
      
      GPIO.output(G,GPIO.HIGH)
     
    if y==7:
      GPIO.output(H,GPIO.LOW)
    else:
      
      GPIO.output(H,GPIO.HIGH)
      
    if x!=0 and x!=1 and x!=2 and x!=3 and x!=4 and x!=5 and x!=6 and x!=7:
        messagebox.showwarning(message="Número de filas es erratico", title="Editado incorrecto")
    
    elif y!=0 and y!=1 and y!=2 and y!=3 and y!=4 and y!=5 and y!=6 and y!=7:
        messagebox.showwarning(message="Número de columnas es erratico", title="Editado incorrecto")
    else:
        time.sleep(5)
        inicio_leds()
    
      
    
    
    
#GPIO.setwarnings(False)
#GPIO.setmode(GPIO.BOARD) # definimos la numeracion     
#inicio_leds()


'''for x in range(8):
    for y in range(8):
        enciendeled(x,y)
        time.sleep(1)'''
#enciendeled(x,y)

#inicio_leds()