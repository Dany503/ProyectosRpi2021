#Aquí se aladirán los import necesarios para el funcionamiento de las funciones
import pandas as pd
from datetime import date
from isbntools.app import *
import os.path

#Añade un libro a la base de datos. Requiere los valores necesarios para la base de datos.
#Devuelve un valor booleano True si se han podido guardar los datos y False en caso contrario.
def anadirLibro(isbn:str,titulo:str,autor:str,coleccion:str,tematica:str,fecha:str,estanteFil:int,estanteCol:int):
    try:
        df=pd.DataFrame([], columns=["isbn","titulo","autor","coleccion","tematica","fecha","adquirido","estanteFil","estanteCol"], index=[])
        df.loc[0,"isbn"]=isbn
        df.loc[0,"titulo"]=titulo
        df.loc[0,"autor"]=autor
        df.loc[0,"coleccion"]=coleccion
        df.loc[0,"tematica"]=tematica
        df.loc[0,"fecha"]=fecha
        df.loc[0,"adquirido"]=date.today().strftime("%d/%m/%Y")
        df.loc[0,"estanteFil"]=estanteFil   #ToDo:ordenar libros
        df.loc[0,"estanteCol"]=estanteCol
        df.to_csv('db.csv', mode='a', header=not(os.path.isfile('db.csv')),index=False)
        return True
    except:
        return False

#Edita un libro de la base de datos. Requiere los valores necesarios para la base de datos.
#Devuelve un valor booleano True si se han podido guardar los datos y False en caso contrario.
def editarLibro(id,isbn:str,titulo:str,autor:str,coleccion:str,tematica:str,fecha:str,estanteFil:int,estanteCol:int):
    try:
        df=pd.read_csv('db.csv',dtype=str)
        id=int(id)
        df.loc[id,"isbn"]=isbn
        df.loc[id,"titulo"]=titulo
        df.loc[id,"autor"]=autor
        df.loc[id,"coleccion"]=coleccion
        df.loc[id,"tematica"]=tematica
        df.loc[id,"fecha"]=fecha
        df.loc[id,"adquirido"]=date.today().strftime("%d/%m/%Y")
        df.loc[id,"estanteFil"]=estanteFil
        df.loc[id,"estanteCol"]=estanteCol
        df.to_csv('db.csv',index=False)
        return True
    except:
        return False

#Elimina un libro de la base de datos. Requiere la ID del libro a eliminar.
#Devuelve un valor booleano True si se han podido eliminar los datos y False en caso contrario.
def eliminarLibro(id:int):
    try:
        df=pd.read_csv('db.csv',dtype=str)
        id=int(id)
        df=df.drop(id)
        df.to_csv('db.csv',index=False)
        return True
    except:
        return False

#Busca libros en la base de datos. Requiere los datos de los libros a buscar.
#Devuelve un dataframe con los datos de cada libro encontrado.
def buscaLibro(isbn:str,titulo:str,autor:str,coleccion:str,tematica:str,tab):
    df=pd.read_csv('db.csv',dtype=str)
    dfl=df.copy()
    try:
        if(isbn!=""): #si se han introducido datos en el campo
            df.dropna(subset = ["isbn"], inplace=True) #Elimina libros con el campo en blanco
            dfl=df.copy() #recorta el dataframe para comparar
            dfl["isbn"] = df["isbn"].str.lower() #En principio el ISBN es un campo numérico. No obstante, la base de datos admite strings, así que no está de más en caso de que se utilice de otra forma.
            df= df[dfl['isbn'].str.contains(isbn.lower())] #La comparación en lower case permite ignorar el uso de mayúsculas

        if(titulo!=""): #si se han introducido datos en el campo
            df.dropna(subset = ["titulo"], inplace=True) #Elimina libros con el campo en blanco
            dfl=df.copy() #recorta el dataframe para comparar
            dfl["titulo"] = df["titulo"].str.lower() 
            df= df[dfl['titulo'].str.contains(titulo.lower())] 

        if(autor!=""): #si se han introducido datos en el campo
            df.dropna(subset = ["autor"], inplace=True) #Elimina libros con el campo en blanco
            dfl=df.copy() #recorta el dataframe para comparar
            dfl["autor"] = df["autor"].str.lower() 
            df= df[dfl['autor'].str.contains(autor.lower())] 

        if(coleccion!=""): #si se han introducido datos en el campo
            df.dropna(subset = ["coleccion"], inplace=True) #Elimina libros con el campo en blanco
            dfl=df.copy() #recorta el dataframe para comparar
            dfl["coleccion"] = df["coleccion"].str.lower() 
            df= df[dfl['coleccion'].str.contains(coleccion.lower())] 

        if(tematica!=""): #si se han introducido datos en el campo
            df.dropna(subset = ["tematica"], inplace=True) #Elimina libros con el campo en blanco
            dfl=df.copy() #recorta el dataframe para comparar
            dfl["tematica"] = df["tematica"].str.lower() 
            df= df[dfl['tematica'].str.contains(tematica.lower())] 

    
        for index, row in df.iterrows():
            tab.insert('',0,text=str(index),values=(row['titulo'],row['autor'],row['tematica'],row['coleccion'],row['isbn'],row['fecha'],row['estanteFil'],row['estanteCol']))
        return True
    except Exception as e:
        print(e)
        return False

#Ilumina el estante correspondiente a un libro almacenado en la base de datos a partir de su id
def enciendeEstante(fil,col):
    #ToDo: leer la base de datos
    ret=[0,0]
    pass

#Actualiza una tabla de tipo treeview con los datos almacenados en la base de datos.
def actualizaTabla(tab):
    for element in tab.get_children():
        tab.delete(element)
    try:
        df=pd.read_csv('db.csv',dtype=str)
        for index, row in df.iterrows():
            tab.insert('',0,text=str(index),values=(row['titulo'],row['autor'],row['tematica'],row['coleccion'],row['isbn'],row['fecha'],row['estanteFil'],row['estanteCol']))
    except:
        pass
    pass

#Devuelve la lista de índices de la tabla UNUSED
def indicesTabla():

    return 0

#Devuelve los datos de un elemento de la tabla UNUSED
def leeTabla(indice:int):
    #ToDo:
    ret=[]
    ret[0]='Ulisses Moore y la casa de los espejos'
    ret[1]='Pierdomenico'
    ret[2]='Fantasía'
    ret[3]='Ulisses Moore'
    ret[4]='67577776454'
    ret[5]='6 5 21'
    return ret
