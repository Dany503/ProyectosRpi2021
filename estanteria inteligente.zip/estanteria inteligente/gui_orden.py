import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import func as fc
from cidebar import camarita

from matrizleds import enciendeled
import wikipedia



class Frame3(tk.Frame):
    def __init__(self, root = None):
        super().__init__(root)
        self.root = root
        self.pack(
            side=tk.TOP,
            fill=tk.BOTH,
            expand=True
        )
        
        
        
        #self.config(width = 870, height = 500)
        self.grid_rowconfigure(0,weight=1)
        
        
        self.label_titulo=tk.Label(self, text='Buscar por categorías')
        self.label_titulo.config(font=('Arial',17,'bold'))
        self.label_titulo.grid(row=0,column=1, padx=1, pady=4)
        
        
        
        self.imagen2=tk.PhotoImage(file="LogoReducido2.png")
        self.imagen12=tk.Label(self, image=self.imagen2)
        self.imagen12.grid(row=0,column=0,padx=0, pady=0)
        
        #Campos libros
        self.label_titulo=tk.Label(self, text='Título: ')
        self.label_titulo.config(font=('Arial',11,'bold'))
        self.label_titulo.grid(row=1,column=0, padx=0, pady=1)

        self.label_au=tk.Label(self, text='Autor: ')
        self.label_au.config(font=('Arial',11,'bold'))
        self.label_au.grid(row=2,column=0,padx=0, pady=1)

        self.label_c=tk.Label(self, text='Temática: ')
        self.label_c.config(font=('Arial',11,'bold'))
        self.label_c.grid(row=3,column=0,padx=0, pady=1)

        self.label_col=tk.Label(self, text='Colección: ')
        self.label_col.config(font=('Arial',11,'bold'))
        self.label_col.grid(row=4,column=0,padx=0, pady=1)

        self.label_isbn=tk.Label(self, text='ISBN: ')
        self.label_isbn.config(font=('Arial',11,'bold'))
        self.label_isbn.grid(row=5,column=0,padx=0, pady=1)
        
        self.label_correo=tk.Label(self, text='Correo: ')
        self.label_correo.config(font=('Arial',11,'bold'))
        self.label_correo.grid(row=7,column=0,padx=0, pady=1)

        self.displaytitulo=tk.StringVar()
        self.entry_displaytitulo=tk.Entry(self, textvariable=self.displaytitulo)
        self.entry_displaytitulo.config(width=60, font=('Arial',10))
        self.entry_displaytitulo.grid(row=1,column=1,padx=10, pady=1)
        


        self.displayau=tk.StringVar()
        self.entry_displayau=tk.Entry(self, textvariable=self.displayau)
        self.entry_displayau.config(width=60, font=('Arial',10))
        self.entry_displayau.grid(row=2,column=1,padx=0, pady=1)

        

        #entrada escritura para genero
        self.c=tk.StringVar()
        self.entry_c=tk.Entry(self, textvariable=self.c)
        self.entry_c.config(width=60, font=('Arial',10))
        self.entry_c.grid(row=3,column=1,padx=0, pady=1)
        # otros displays
        self.col=tk.StringVar()
        self.entry_col=tk.Entry(self, textvariable=self.col)
        self.entry_col.config(width=60, font=('Arial',10))
        self.entry_col.grid(row=4,column=1,padx=0, pady=1)

        self.isbn=tk.StringVar()
        self.entry_isbn=tk.Entry(self, textvariable=self.isbn)
        self.entry_isbn.config(width=60, font=('Arial',10))
        self.entry_isbn.grid(row=5,column=1,padx=0, pady=1)
        
        self.correo=tk.StringVar()
        self.entry_correo=tk.Entry(self, textvariable=self.correo)
        self.entry_correo.config(width=60, font=('Arial',10))
        self.entry_correo.grid(row=7,column=1,padx=0, pady=1)

        self.entry_displayau.config(state='normal')
        self.entry_displaytitulo.config(state='normal')
        self.entry_c.config(state='normal')
        self.entry_col.config(state='normal')
        self.entry_isbn.config(state='normal')
        self.entry_correo.config(state='normal')

        #display fila y columna
        self.fila=tk.StringVar()
        self.entry_fila=tk.Entry(self, textvariable=self.fila)
        self.entry_fila.config(width=30, font=('Arial',10))
        self.entry_fila.grid(row=10,column=2,padx=0, pady=1)

        self.columna=tk.StringVar()
        self.entry_columna=tk.Entry(self, textvariable=self.columna)
        self.entry_columna.config(width=30, font=('Arial',10))
        self.entry_columna.grid(row=9,column=2,padx=0, pady=1)

        self.label_titulo=tk.Label(self, text='Fila')
        self.label_titulo.config(font=('Arial',11))
        self.label_titulo.grid(row=10,column=1, padx=0, pady=10)

        self.label_titulo=tk.Label(self, text='Columna: ')
        self.label_titulo.config(font=('Arial',11))
        self.label_titulo.grid(row=9,column=1, padx=0, pady=1)
        
        self.entry_fila.config(state='disabled')
        self.entry_columna.config(state='disabled')
        
        #--botones
        self.boton_edi=tk.Button(self, text="Buscar autor en Wikipedia",command=self.buscar_wiki)
        self.boton_edi.config(width=20,font=('Arial',9),
                                                fg='#DAD5D6',bg='#999999',activebackground='#15D659')
        self.boton_edi.grid(row=0,column=2,padx=0, pady=1)

        self.boton_edi=tk.Button(self, text="Buscar",command=self.buscar)
        self.boton_edi.config(width=20,font=('Arial',11),
                                                fg='#DAD5D6',bg='#158645',activebackground='#158659')
        self.boton_edi.grid(row=6,column=0,padx=10, pady=1)
        
        self.boton_edi=tk.Button(self, text="Borrar",command=self.borrar)
        self.boton_edi.config(width=20,font=('Arial',11),
                                                fg='#DAD5D6',bg='#151145',activebackground='#158659')
        self.boton_edi.grid(row=6,column=1,padx=10, pady=1)

        self.boton_edil=tk.Button(self, text="Indicar LED",command=self.encender)
        self.boton_edil.config(width=20,font=('Arial',11),
                                                fg='#DAD5D6',bg='#157205',activebackground='#158699')
        self.boton_edil.grid(row=8,column=0,padx=10, pady=1)
        
        self.boton_edic=tk.Button(self, text="Usar Cámara",command=self.camara)
        self.boton_edic.config(width=20,font=('Arial',11),
                                                fg='#DAD5D6',bg='#111945',activebackground='#158699')
        self.boton_edic.grid(row=8,column=1,padx=1, pady=1)
        
        self.boton_edil=tk.Button(self, text="Devolver",command=self.devolver)
        self.boton_edil.config(width=20,font=('Arial',11),
                                                fg='#DAD5D6',bg='#111949',activebackground='#158699')
        self.boton_edil.grid(row=9,column=0,padx=10, pady=1)
        
        self.boton_edil=tk.Button(self, text="Prestar",command=self.prestar)
        self.boton_edil.config(width=20,font=('Arial',11),
                                                fg='#DAD5D6',bg='#666666',activebackground='#158699')
        self.boton_edil.grid(row=10,column=0,padx=10, pady=1)
        
    def buscar_wiki(self):
        try:
        
            self.autor_libro= self.tabla.item(self.tabla.selection())['values'][1]
            summaryy=wikipedia.summary(self.autor_libro,sentences=1)
            messagebox.showinfo(message=summaryy, title="Wikipedia")
            
        except:
            tit='Wikipedia'
            mensaje='No encontrado o no ha seleccionado ningún  registro'
            messagebox.showerror(tit,mensaje)
        
        
    def devolver(self):
        try:
            self.identificador_libro= self.tabla.item(self.tabla.selection())['text']
        
            
            if(fc.devuelveLibro(self.identificador_libro)):
                
                tit='Devolución'
                mensaje='Se te ha devuelto el libro'
                messagebox.showinfo(tit,mensaje)
            else:
                tit='Devolución'
                mensaje='No está prestado '
                messagebox.showinfo(tit,mensaje)
        except Exception as e:
            tit='Devolver'
            mensaje='Error'
            messagebox.showerror(tit,mensaje)
        
       
        
    def prestar(self):
        try:
            self.identificador_libro= self.tabla.item(self.tabla.selection())['text']
            if(fc.prestaLibro(self.identificador_libro,self.correo.get())):
            
                tit='Prestamo'
                mensaje='Se te ha prestado el libro'
                messagebox.showinfo(tit,mensaje)
            else:
                tit='Prestamo'
                mensaje='Ya está prestado a otra persona'
                messagebox.showerror(tit,mensaje)
            
        except Exception as e:
            tit='Prestamo'
            mensaje='Pon el correo bien'
            messagebox.showerror(tit,mensaje)
            
   
        
    def borrar(self):
        self.c.set('')#vaciamos el recuadro que se rellenó
        self.displaytitulo.set('')
        self.displayau.set('')
        self.col.set('')
        self.isbn.set('')
        #self.fecha.set('')
        self.fila.set('')
        self.columna.set('')
        self.correo.set('')
    

    def camara(self):
        
        #aquí dentro se habilitaría inicio de leer camara el código de barras
        try:
            meta_dict=camarita()
            

            titulo=meta_dict["Title"]#esto seria lo que devolvera la función que lee la camara
            autor=",".join(meta_dict["Authors"])
            isbnn=meta_dict["ISBN-13"]
            #ffecha=meta_dict["Year"]

            self.displaytitulo.set(titulo)
            self.displayau.set(autor)
            
            self.isbn.set(isbnn)
            #self.fecha.set(ffecha)
        except:
            
            tit='Edición de datos'
            mensaje='ISBN no identificado'
            messagebox.showerror(tit,mensaje)
        
        
        

    def encender(self):
        try:
            #primero recupero datos de la tabla
            self.identificador_libro= self.tabla.item(self.tabla.selection())['text']
            self.titulo_libro= self.tabla.item(self.tabla.selection())['values'][0]
            self.autor_libro= self.tabla.item(self.tabla.selection())['values'][1]
            self.genero_libro= self.tabla.item(self.tabla.selection())['values'][2]
            self.mi_coleccion=self.tabla.item(self.tabla.selection())['values'][3]
            self.mi_isbn=self.tabla.item(self.tabla.selection())['values'][4]
            self.mi_fecha=self.tabla.item(self.tabla.selection())['values'][5]
            self.mi_fila_col=self.tabla.item(self.tabla.selection())['values'][6].split('/')
            #self.mi_col=self.tabla.item(self.tabla.selection())['values'][7]
            self.mi_fila=self.mi_fila_col[0]
            self.mi_col=self.mi_fila_col[1]
            print()
            #--

            
            self.entry_fila.config(state='normal')
            self.entry_columna.config(state='normal')
            self.fila.set('')
            self.columna.set('')
            self.entry_columna.insert(0,self.mi_col)
            self.entry_fila.insert(0,self.mi_fila)

            self.entry_fila.config(state='disabled')
            self.entry_columna.config(state='disabled')
            
            try:
                mi_col=int(self.mi_col)
                mi_fil=int(self.mi_fila)
                
                
                enciendeled(mi_fil,mi_col)
                
                
            except:
                tit='Error led'
                mensaje='La fila o columna no esta bien configurada'
                messagebox.showerror(tit,mensaje)


        except:
            tit='Edición de datos'
            mensaje='No ha seleccionado ningún  registro'
            messagebox.showerror(tit,mensaje)
        
    def buscar(self):
        self.tabla_estanteria()

    def tabla_estanteria(self):
        
        self.tabla=ttk.Treeview(self, column=('Título','Autor','Temática','Colección','ISBN','Fecha','Estante fila/col','Prestamo'))
        self.tabla.grid(row=11, column=0, columnspan=9,sticky='nse')
    
        self.scroll=ttk.Scrollbar(self, orient='vertical', command=self.tabla.yview) #deslizador para tabla cuando no se pueden visualizar todos
        self.scroll.grid(row=11,column=9,sticky='nse')

        

        self.tabla.heading('#0', text='Identificador')
        self.tabla.heading('#1', text='Titulo')
        self.tabla.heading('#2', text='Autor')
        self.tabla.heading('#3', text='Temática')
        self.tabla.heading('#4', text='Colección')
        self.tabla.heading('#5', text='ISBN')
        self.tabla.heading('#6', text='Fecha')
        self.tabla.heading('#7', text='Estante fila/col')
        
        self.tabla.heading('#8', text='Prestamo')

        
        #self.tabla.insert('',0,text='1',values=('Ulisses Moore y los guardianes de piedra','Pierdomenico','Fantasía','Ulisses Moore','675645456454','6 5 21','1','4'))
        #self.tabla.insert('',0,text='2',values=('Ulisses Moore y la casa de los espejos','Pierdomenico','Fantasía','Ulisses Moore','67577776454','6 5 21','1','9'))
        if(fc.buscaLibro(self.isbn.get(),self.displaytitulo.get(),self.displayau.get(),self.col.get(),self.c.get(),self.tabla)):
            pass
        else:
            messagebox.showerror('Error','No se ha podido encontrar en la base de datos')
        


        
